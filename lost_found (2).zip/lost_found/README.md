# University Lost & Found Portal
### CS 2005 – Database Systems Project | FAST NUCES Spring 2026
**Group Members:** Zakia Nadeem (24K-0692) · Simroz Sohail (24K-0746) · Abeela Khan (24K-0965)

---

## Tech Stack
| Layer    | Technology             |
|----------|------------------------|
| Frontend | HTML5, CSS3, Bootstrap 5, JavaScript |
| Backend  | PHP 8+ (PDO)           |
| Database | MySQL 8+               |

---

## Setup Instructions

### 1. Database
```sql
-- In phpMyAdmin or MySQL CLI:
SOURCE /path/to/lost_found/database.sql;
```
This creates the `db_project` database with all tables, views, stored procedures, and sample data.

### 2. Backend Configuration
Open `includes/db.php` and update:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'db_project');
define('DB_USER', 'root');      // your MySQL username
define('DB_PASS', '');          // your MySQL password
```

### 3. Web Server
- Place the `lost_found/` folder inside your web server root:
  - **XAMPP:** `C:/xampp/htdocs/lost_found/`
  - **WAMP:**  `C:/wamp64/www/lost_found/`
- Access via: `http://localhost/lost_found/`

### 4. Default Login Credentials
| Role    | Email              | Password   |
|---------|--------------------|------------|
| Admin   | admin@nu.edu.pk    | password   |
| Student | ali@nu.edu.pk      | password   |
| Student | sara@nu.edu.pk     | password   |

---

## Project Structure
```
lost_found/
├── index.php               Captivating Landing Page (Public)
├── login.php               User & Admin Login Page
├── register.php            User registration
├── logout.php
├── database.sql            Full DB schema + sample data
├── includes/
│   ├── db.php              PDO database connection
│   ├── auth.php            Session & role helpers
│   └── layout.php          Shared header/footer
├── user/
│   ├── dashboard.php       User home + suggested matches
│   ├── report_lost.php     Report a lost item (INSERT)
│   ├── report_found.php    Report a found item (INSERT)
│   ├── search.php          Search/filter found items
│   ├── my_reports.php      View & delete own reports
│   └── my_claims.php       Submit & track claims
├── admin/
│   ├── dashboard.php       Admin home + stats
│   ├── manage_claims.php   Approve/reject claims (TRANSACTION)
│   ├── manage_reports.php  View & delete all reports
│   └── handovers.php       Record item handovers
├── css/
│   └── style.css
└── js/
    └── main.js
```

---

## Database Schema (6 Tables + Views + Stored Procedures)

### Tables
1. **Users** — Students, staff, admin accounts
2. **Lost_Items** — Items reported as lost
3. **Found_Items** — Items reported as found
4. **Claims** — Ownership claims on found items
5. **Admin_Actions** — Log of all admin decisions
6. **Matches** — Auto-generated lost↔found pairings

### Views
- `v_active_matches` — Active matched item pairs
- `v_claim_summary` — Full claim details with user info
- `v_user_activity` — Per-user activity statistics

### Stored Procedures
- `sp_generate_matches(lost_id)` — Auto-match a new lost item (User role)
- `sp_approve_claim(claim_id, admin_id, remarks)` — Transactional approval (Admin role)
- `sp_system_stats()` — System-wide statistics report (Admin role)

---

## SQL Features Implemented

| Requirement                  | Where                                                    |
|------------------------------|----------------------------------------------------------|
| **JOINs**                    | All dashboard, search, and admin pages                   |
| **Advanced SQL** (subqueries)| User dashboard stats, my_reports claim count             |
| **GROUP BY + Aggregates**    | Admin dashboard category breakdown                       |
| **CASE expressions**         | Claims status label, match scoring                       |
| **Built-in Functions**       | `COUNT`, `DATEDIFF`, `DATE_FORMAT`, `NOW`, `LOWER`, `NULLIF` |
| **Dynamic user input**       | Search filters, login, all form submissions (parameterised) |
| **INSERT**                   | Register, report lost/found, submit claim                |
| **UPDATE**                   | Approve/reject claims, handover status                   |
| **DELETE**                   | User & admin delete reports                              |
| **TRANSACTIONS**             | `manage_claims.php`, `handovers.php`, `sp_approve_claim` |
| **Views**                    | `v_active_matches`, `v_claim_summary`, `v_user_activity` |
| **Stored Procedures**        | 3 procedures covering both user and admin roles          |
