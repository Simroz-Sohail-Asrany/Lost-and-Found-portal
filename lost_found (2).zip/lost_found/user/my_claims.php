<?php
// ─────────────────────────────────────────────────
//  user/my_claims.php  —  Submit & Track Claims
//  Demonstrates: INSERT claim, JOIN query,
//  advanced SQL: CASE expression
// ─────────────────────────────────────────────────
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
requireUser();

$uid      = $_SESSION['user_id'];
$foundId  = (int)($_GET['found_id'] ?? 0);
$errors   = [];
$item     = null;

// ── Load item details if found_id supplied ────────────────────────────
if ($foundId > 0) {
    $stmt = $pdo->prepare("
        SELECT fi.*, u.name AS reporter_name
        FROM Found_Items fi
        JOIN Users u ON u.user_id = fi.user_id
        WHERE fi.found_id = ? AND fi.status = 'available'
    ");
    $stmt->execute([$foundId]);
    $item = $stmt->fetch();
    if (!$item) { $foundId = 0; }
}

// ── Handle Claim Submission ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_claim'])) {
    $fid   = (int)($_POST['found_id'] ?? 0);
    $proof = trim($_POST['proof'] ?? '');

    if ($fid   <= 0)    $errors[] = 'Invalid item selected.';
    if ($proof === '')  $errors[] = 'Proof of ownership is required.';

    if (empty($errors)) {
        // Check: user hasn't already claimed this item
        $chk = $pdo->prepare("SELECT claim_id FROM Claims WHERE user_id = ? AND found_id = ?");
        $chk->execute([$uid, $fid]);
        if ($chk->fetch()) {
            $errors[] = 'You have already submitted a claim for this item.';
        } else {
            // INSERT claim
            $ins = $pdo->prepare("
                INSERT INTO Claims (user_id, found_id, proof, status, created_at)
                VALUES (?, ?, ?, 'pending', NOW())
            ");
            $ins->execute([$uid, $fid, $proof]);
            setFlash('success', 'Claim submitted! The admin will review it shortly.');
            header('Location: my_claims.php'); exit;
        }
    }
}

// ── Fetch user's claims (JOIN: Claims ↔ Found_Items ↔ Users, CASE) ───
// Advanced SQL: CASE for status label, JOIN across 3 tables
$claims = $pdo->prepare("
    SELECT
        c.claim_id,
        c.proof,
        c.status,
        c.created_at,
        fi.title        AS item_title,
        fi.category,
        fi.location,
        u.name          AS reporter_name,
        DATE_FORMAT(c.created_at, '%d %b %Y') AS submitted_on,
        CASE c.status
            WHEN 'pending'  THEN 'Your claim is under review.'
            WHEN 'approved' THEN 'Claim approved! Contact admin to collect your item.'
            WHEN 'rejected' THEN 'Claim was rejected. You may contact admin for details.'
        END AS status_message
    FROM Claims c
    JOIN Found_Items fi ON fi.found_id = c.found_id
    JOIN Users u        ON u.user_id   = fi.user_id
    WHERE c.user_id = ?
    ORDER BY c.created_at DESC
");
$claims->execute([$uid]);
$myClaims = $claims->fetchAll();

header_html('My Claims', 'user');
?>

<?= getFlash() ?>

<div class="page-header">
  <h2><i class="bi bi-hand-index me-2 text-primary"></i>My Claims</h2>
  <p class="text-muted mb-0">Submit and track your item claims.</p>
</div>

<?php if ($foundId > 0 && $item): ?>
<!-- Claim Submission Form for a specific item -->
<div class="row justify-content-center mb-4">
  <div class="col-lg-7">
    <div class="card border-primary">
      <div class="card-header bg-primary text-white">
        <i class="bi bi-hand-index me-2"></i>Submit Claim for: <?= htmlspecialchars($item['title']) ?>
      </div>
      <div class="card-body">
        <div class="alert alert-info py-2 mb-3">
          <strong>Item Details:</strong>
          <?= htmlspecialchars($item['category']) ?> · Found at <?= htmlspecialchars($item['location']) ?>
          · Reported by <?= htmlspecialchars($item['reporter_name']) ?>
        </div>

        <?php if (!empty($errors)): ?>
          <div class="alert alert-danger">
            <ul class="mb-0 ps-3">
              <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
            </ul>
          </div>
        <?php endif; ?>

        <form method="POST" novalidate>
          <input type="hidden" name="found_id" value="<?= $foundId ?>">
          <div class="mb-3">
            <label class="form-label fw-semibold">
              Proof of Ownership <span class="text-danger">*</span>
            </label>
            <textarea name="proof" class="form-control" rows="4"
                      data-maxlength="600"
                      placeholder="Describe identifying features, when/where you lost it, any unique marks, serial number, etc."
                      required></textarea>
            <div class="form-text">Be as specific as possible to help the admin verify your claim.</div>
          </div>
          <div class="d-flex gap-2">
            <button type="submit" name="submit_claim" class="btn btn-primary fw-semibold px-4">
              <i class="bi bi-send me-2"></i>Submit Claim
            </button>
            <a href="my_claims.php" class="btn btn-outline-secondary px-4">Cancel</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- All Claims -->
<h5 class="fw-bold mb-3">Claim History</h5>

<?php if (empty($myClaims)): ?>
  <div class="card text-center p-5 text-muted">
    <i class="bi bi-inbox fs-1 d-block mb-3"></i>
    <p>You haven't submitted any claims yet.</p>
    <a href="search.php" class="btn btn-primary">Search Found Items</a>
  </div>
<?php else: ?>
  <div class="row g-3">
  <?php foreach ($myClaims as $c): ?>
    <div class="col-md-6">
      <div class="card h-100">
        <div class="card-body">
          <div class="d-flex justify-content-between mb-2">
            <h6 class="fw-bold mb-0"><?= htmlspecialchars($c['item_title']) ?></h6>
            <span class="badge
              <?= $c['status']==='approved'?'bg-success':($c['status']==='rejected'?'bg-danger':'bg-secondary') ?>">
              <?= ucfirst($c['status']) ?>
            </span>
          </div>
          <div class="small text-muted mb-2">
            <i class="bi bi-tag me-1"></i><?= htmlspecialchars($c['category']) ?>
            &nbsp;·&nbsp;
            <i class="bi bi-calendar me-1"></i>Submitted <?= $c['submitted_on'] ?>
          </div>
          <div class="alert
            <?= $c['status']==='approved'?'alert-success':($c['status']==='rejected'?'alert-danger':'alert-secondary') ?>
            py-2 mb-2 small">
            <?= $c['status_message'] ?>
          </div>
          <details>
            <summary class="small text-muted" style="cursor:pointer">Your proof statement</summary>
            <p class="small mt-2 mb-0"><?= htmlspecialchars($c['proof']) ?></p>
          </details>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php footer_html(); ?>
