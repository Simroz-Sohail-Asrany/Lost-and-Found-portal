<?php
// ─────────────────────────────────────────────────
//  user/dashboard.php  —  User Home
// ─────────────────────────────────────────────────
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
requireUser();

$uid = $_SESSION['user_id'];

// ── Stats for this user (Built-in SQL functions: COUNT, DATEDIFF) ─────
$stats = $pdo->prepare("
    SELECT
        (SELECT COUNT(*) FROM Lost_Items  WHERE user_id = :uid)                       AS total_lost,
        (SELECT COUNT(*) FROM Found_Items WHERE user_id = :uid2)                      AS total_found,
        (SELECT COUNT(*) FROM Claims      WHERE user_id = :uid3)                      AS total_claims,
        (SELECT COUNT(*) FROM Claims      WHERE user_id = :uid4 AND status='approved') AS approved_claims
");
$stats->execute([':uid'=>$uid, ':uid2'=>$uid, ':uid3'=>$uid, ':uid4'=>$uid]);
$s = $stats->fetch();

// ── Recent suggested matches (JOIN: Lost_Items ↔ Found_Items on category) ──
// Advanced SQL: subquery + JOIN to find items that share same category
$matches = $pdo->prepare("
    SELECT
        li.lost_id,
        li.title           AS lost_title,
        fi.found_id,
        fi.title           AS found_title,
        fi.category,
        fi.location        AS found_location,
        DATEDIFF(NOW(), fi.date_found) AS days_ago
    FROM Lost_Items li
    JOIN Found_Items fi ON LOWER(fi.category) = LOWER(li.category)
    WHERE li.user_id = :uid
      AND li.status  = 'open'
      AND fi.status  = 'available'
    ORDER BY fi.date_found DESC
    LIMIT 5
");
$matches->execute([':uid' => $uid]);
$matchRows = $matches->fetchAll();

// ── Recent lost items ─────────────────────────────────────────────────
$recent = $pdo->prepare("
    SELECT lost_id, title, category, location, date_lost, status
    FROM Lost_Items
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 3
");
$recent->execute([$uid]);
$recentLost = $recent->fetchAll();

// ── Recent found items ─────────────────────────────────────────────────
$recentF = $pdo->prepare("
    SELECT found_id, title, category, location, date_found, status
    FROM Found_Items
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 3
");
$recentF->execute([$uid]);
$recentFound = $recentF->fetchAll();

header_html('Dashboard', 'user');
?>

<?= getFlash() ?>

<div class="page-header d-flex align-items-center justify-content-between">
  <div>
    <h2><i class="bi bi-grid-1x2 me-2 text-primary"></i>My Dashboard</h2>
    <p class="text-muted mb-0">Welcome back, <?= htmlspecialchars($_SESSION['name']) ?>!</p>
  </div>
  <div class="d-flex gap-2">
    <a href="/lost_found/user/report_lost.php"  class="btn btn-danger btn-sm fw-semibold">
      <i class="bi bi-exclamation-circle me-1"></i>Report Lost
    </a>
    <a href="/lost_found/user/report_found.php" class="btn btn-success btn-sm fw-semibold">
      <i class="bi bi-check-circle me-1"></i>Report Found
    </a>
  </div>
</div>

<!-- Stats Row -->
<div class="row g-3 mb-4">
  <div class="col-6 col-md-3">
    <div class="stat-box">
      <div class="stat-num text-danger"><?= $s['total_lost'] ?></div>
      <div class="stat-label">Lost Reports</div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="stat-box">
      <div class="stat-num text-success"><?= $s['total_found'] ?></div>
      <div class="stat-label">Found Reports</div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="stat-box">
      <div class="stat-num text-primary"><?= $s['total_claims'] ?></div>
      <div class="stat-label">Claims Submitted</div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="stat-box">
      <div class="stat-num text-warning"><?= $s['approved_claims'] ?></div>
      <div class="stat-label">Approved Claims</div>
    </div>
  </div>
</div>

<div class="row g-4">
  <!-- Suggested Matches -->
  <div class="col-lg-7">
    <div class="card h-100">
      <div class="card-header bg-warning text-dark">
        <i class="bi bi-magic me-2"></i>Suggested Matches
        <span class="badge bg-dark ms-2"><?= count($matchRows) ?></span>
      </div>
      <div class="card-body p-0">
        <?php if (empty($matchRows)): ?>
          <div class="p-4 text-muted text-center">
            <i class="bi bi-inbox fs-2 d-block mb-2"></i>No matches found yet.
          </div>
        <?php else: ?>
          <table class="table table-hover mb-0">
            <thead><tr>
              <th>Your Lost Item</th><th>Possible Match</th><th>Category</th><th>Days Ago</th><th></th>
            </tr></thead>
            <tbody>
            <?php foreach ($matchRows as $m): ?>
              <tr>
                <td><?= htmlspecialchars($m['lost_title']) ?></td>
                <td><?= htmlspecialchars($m['found_title']) ?></td>
                <td><span class="category-pill"><?= htmlspecialchars($m['category']) ?></span></td>
                <td><?= $m['days_ago'] ?> days</td>
                <td>
                  <a href="/lost_found/user/my_claims.php?found_id=<?= $m['found_id'] ?>"
                     class="btn btn-sm btn-outline-primary">Claim</a>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Recent Reports -->
  <div class="col-lg-5">
    <!-- Lost Items -->
    <div class="card mb-4">
      <div class="card-header bg-danger text-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-exclamation-circle me-2"></i>My Lost Reports</span>
        <a href="/lost_found/user/my_reports.php" class="btn btn-sm btn-light">All</a>
      </div>
      <div class="card-body p-0">
        <?php if (empty($recentLost)): ?>
          <div class="p-3 text-muted text-center small">No lost reports yet.</div>
        <?php else: ?>
          <ul class="list-group list-group-flush">
          <?php foreach ($recentLost as $item): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center py-2">
              <div class="small">
                <div class="fw-semibold text-truncate" style="max-width: 150px;"><?= htmlspecialchars($item['title']) ?></div>
                <div class="text-muted" style="font-size: 0.75rem;"><?= $item['date_lost'] ?></div>
              </div>
              <span class="badge rounded-pill badge-<?= $item['status'] ?> small">
                <?= ucfirst($item['status']) ?>
              </span>
            </li>
          <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>

    <!-- Found Items -->
    <div class="card">
      <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-check-circle me-2"></i>My Found Reports</span>
        <a href="/lost_found/user/my_reports.php" class="btn btn-sm btn-light">All</a>
      </div>
      <div class="card-body p-0">
        <?php if (empty($recentFound)): ?>
          <div class="p-3 text-muted text-center small">No found reports yet.</div>
        <?php else: ?>
          <ul class="list-group list-group-flush">
          <?php foreach ($recentFound as $item): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center py-2">
              <div class="small">
                <div class="fw-semibold text-truncate" style="max-width: 150px;"><?= htmlspecialchars($item['title']) ?></div>
                <div class="text-muted" style="font-size: 0.75rem;"><?= $item['date_found'] ?></div>
              </div>
              <span class="badge rounded-pill badge-<?= $item['status'] ?> small">
                <?= ucfirst($item['status']) ?>
              </span>
            </li>
          <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php footer_html(); ?>
