<?php
// ─────────────────────────────────────────────────
//  user/search.php  —  Search Found Items
//  Demonstrates: JOIN, built-in SQL functions,
//  dynamic user input, LIKE filter
// ─────────────────────────────────────────────────
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
requireUser();

$categories = ['', 'Electronics', 'Stationery', 'Books', 'Clothing', 'Accessories', 'ID/Cards', 'Keys', 'Bag/Wallet', 'Other'];

// ── Collect & sanitize filter inputs (dynamic user input) ─────────────
$type     = in_array($_GET['type'] ?? '', ['found', 'lost']) ? $_GET['type'] : 'found';
$keyword  = trim($_GET['keyword']  ?? '');
$category = trim($_GET['category'] ?? '');
$dateFrom = trim($_GET['date_from'] ?? '');
$dateTo   = trim($_GET['date_to']   ?? '');

// ── Build parameterised query with JOIN + built-in functions ──────────
if ($type === 'found') {
    $sql = "
        SELECT
            fi.found_id                        AS id,
            fi.title,
            fi.category,
            fi.description,
            fi.location,
            fi.date_found                      AS item_date,
            fi.status,
            u.name                             AS reporter_name,
            DATE_FORMAT(fi.date_found,'%d %b %Y') AS item_date_fmt,
            DATEDIFF(NOW(), fi.date_found)     AS days_ago
        FROM Found_Items fi
        JOIN Users u ON u.user_id = fi.user_id
        WHERE fi.status = 'available'
    ";
} else {
    $sql = "
        SELECT
            li.lost_id                         AS id,
            li.title,
            li.category,
            li.description,
            li.location,
            li.date_lost                       AS item_date,
            li.status,
            u.name                             AS reporter_name,
            DATE_FORMAT(li.date_lost,'%d %b %Y')  AS item_date_fmt,
            DATEDIFF(NOW(), li.date_lost)      AS days_ago
        FROM Lost_Items li
        JOIN Users u ON u.user_id = li.user_id
        WHERE li.status = 'open'
    ";
}

$params = [];
$prefix = ($type === 'found' ? 'fi' : 'li');
$dateCol = ($type === 'found' ? 'date_found' : 'date_lost');

if ($keyword !== '') {
    $sql .= " AND ($prefix.title LIKE ? OR $prefix.description LIKE ? OR $prefix.location LIKE ?)";
    $like = "%$keyword%";
    $params[] = $like; $params[] = $like; $params[] = $like;
}
if ($category !== '') {
    $sql .= " AND $prefix.category = ?";
    $params[] = $category;
}
if ($dateFrom !== '') {
    $sql .= " AND $prefix.$dateCol >= ?";
    $params[] = $dateFrom;
}
if ($dateTo !== '') {
    $sql .= " AND $prefix.$dateCol <= ?";
    $params[] = $dateTo;
}
$sql .= " ORDER BY $prefix.$dateCol DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$results = $stmt->fetchAll();

header_html('Search Items', 'user');
?>

<?= getFlash() ?>

<div class="page-header">
  <h2><i class="bi bi-search me-2 text-primary"></i>Search Items</h2>
  <p class="text-muted mb-0">Browse reported items and help reunite them with their owners.</p>
</div>

<!-- Tabs for Type -->
<ul class="nav nav-pills mb-4 bg-light p-2 rounded">
  <li class="nav-item">
    <a class="nav-link <?= $type==='found'?'active':'' ?>" href="?type=found&keyword=<?=urlencode($keyword)?>&category=<?=urlencode($category)?>">
      <i class="bi bi-check-circle me-1"></i>Found Items
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?= $type==='lost'?'active bg-danger':'' ?>" href="?type=lost&keyword=<?=urlencode($keyword)?>&category=<?=urlencode($category)?>">
      <i class="bi bi-exclamation-circle me-1"></i>Lost Items
    </a>
  </li>
</ul>

<!-- Filter Form -->
<div class="card mb-4 border-0 shadow-sm">
  <div class="card-body">
    <form method="GET" class="row g-3 align-items-end">
      <input type="hidden" name="type" value="<?= $type ?>">
      <div class="col-md-4">
        <label class="form-label fw-semibold">Keyword</label>
        <input type="text" name="keyword" class="form-control"
               placeholder="Search title, description, location..."
               value="<?= htmlspecialchars($keyword) ?>">
      </div>
      <div class="col-md-3">
        <label class="form-label fw-semibold">Category</label>
        <select name="category" class="form-select">
          <option value="">All Categories</option>
          <?php foreach (array_filter($categories) as $cat): ?>
            <option value="<?= $cat ?>" <?= $category===$cat?'selected':'' ?>><?= $cat ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2">
        <label class="form-label fw-semibold">From Date</label>
        <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($dateFrom) ?>">
      </div>
      <div class="col-md-2">
        <label class="form-label fw-semibold">To Date</label>
        <input type="date" name="date_to"   class="form-control" value="<?= htmlspecialchars($dateTo) ?>">
      </div>
      <div class="col-md-1 d-flex gap-2">
        <button type="submit" class="btn btn-primary w-100"><i class="bi bi-search"></i></button>
      </div>
    </form>
  </div>
</div>

<!-- Results -->
<div class="mb-3 d-flex justify-content-between align-items-center">
  <div class="text-muted small">
    <?= count($results) ?> <?= $type ?> item(s) found
    <?= $keyword ? ' for "<strong>' . htmlspecialchars($keyword) . '</strong>"' : '' ?>
  </div>
</div>

<?php if (empty($results)): ?>
  <div class="card text-center p-5 text-muted border-0 shadow-sm">
    <i class="bi bi-inbox fs-1 d-block mb-3"></i>
    <h5>No <?= $type ?> items match your search.</h5>
    <p>Try different keywords or remove filters.</p>
  </div>
<?php else: ?>
  <div class="row g-3">
  <?php foreach ($results as $item): ?>
    <div class="col-md-6 col-lg-4">
      <div class="card h-100 border-0 shadow-sm item-card <?= $type==='found'?'found':'' ?>">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start mb-2">
            <span class="category-pill <?= $type==='lost'?'bg-danger-subtle text-danger':'' ?>">
              <?= htmlspecialchars($item['category']) ?>
            </span>
            <small class="text-muted"><?= $item['days_ago'] ?> days ago</small>
          </div>
          <h6 class="fw-bold"><?= htmlspecialchars($item['title']) ?></h6>
          <p class="text-muted small mb-2" style="min-height:40px">
            <?= htmlspecialchars(mb_substr($item['description'], 0, 100)) ?>…
          </p>
          <div class="small text-muted">
            <i class="bi bi-geo-alt me-1"></i><?= htmlspecialchars($item['location']) ?><br>
            <i class="bi bi-calendar me-1"></i><?= $item['item_date_fmt'] ?><br>
            <i class="bi bi-person me-1"></i><?= $type==='found'?'Found':'Lost' ?> by <?= htmlspecialchars($item['reporter_name']) ?>
          </div>
        </div>
        <div class="card-footer bg-transparent border-0 pt-0">
          <?php if ($type === 'found'): ?>
            <a href="/lost_found/user/my_claims.php?found_id=<?= $item['id'] ?>"
               class="btn btn-sm btn-primary w-100 fw-semibold">
              <i class="bi bi-hand-index me-1"></i>This is Mine — Claim It
            </a>
          <?php else: ?>
             <div class="alert alert-info py-1 px-2 mb-0 small text-center">
               <i class="bi bi-info-circle me-1"></i>Reported as Lost
             </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php footer_html(); ?>
