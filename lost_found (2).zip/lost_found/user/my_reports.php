<?php
// ─────────────────────────────────────────────────
//  user/my_reports.php  —  View & Delete My Reports
//  Demonstrates: JOIN, built-in SQL functions,
//                DELETE with WHERE user_id check
// ─────────────────────────────────────────────────
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
requireUser();

$uid = $_SESSION['user_id'];

// ── Handle DELETE (user can only delete their own items) ──────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'delete_lost' && !empty($_POST['lost_id'])) {
        $stmt = $pdo->prepare("DELETE FROM Lost_Items WHERE lost_id = ? AND user_id = ?");
        $stmt->execute([(int)$_POST['lost_id'], $uid]);
        setFlash('success', 'Lost item report deleted.');
    } elseif ($_POST['action'] === 'delete_found' && !empty($_POST['found_id'])) {
        $stmt = $pdo->prepare("DELETE FROM Found_Items WHERE found_id = ? AND user_id = ?");
        $stmt->execute([(int)$_POST['found_id'], $uid]);
        setFlash('success', 'Found item report deleted.');
    }
    header('Location: my_reports.php'); exit;
}

// ── Fetch Lost Items (JOIN with count of related claims via subquery) ─
// Advanced SQL: subquery in SELECT for claim count
$lostItems = $pdo->prepare("
    SELECT
        li.lost_id,
        li.title,
        li.category,
        li.location,
        li.date_lost,
        li.status,
        DATE_FORMAT(li.created_at, '%d %b %Y') AS reported_on,
        DATEDIFF(NOW(), li.date_lost)           AS days_missing,
        (SELECT COUNT(*) FROM Claims c
         JOIN Found_Items fi ON fi.found_id = c.found_id
         WHERE LOWER(fi.category) = LOWER(li.category)
           AND fi.status = 'available') AS potential_matches
    FROM Lost_Items li
    WHERE li.user_id = ?
    ORDER BY li.created_at DESC
");
$lostItems->execute([$uid]);
$lost = $lostItems->fetchAll();

// ── Fetch Found Items ─────────────────────────────────────────────────
$foundItems = $pdo->prepare("
    SELECT
        fi.found_id,
        fi.title,
        fi.category,
        fi.location,
        fi.date_found,
        fi.status,
        DATE_FORMAT(fi.created_at, '%d %b %Y') AS reported_on,
        (SELECT COUNT(*) FROM Claims c WHERE c.found_id = fi.found_id) AS claim_count
    FROM Found_Items fi
    WHERE fi.user_id = ?
    ORDER BY fi.created_at DESC
");
$foundItems->execute([$uid]);
$found = $foundItems->fetchAll();

header_html('My Reports', 'user');

$statusBadge = fn($s) => match($s) {
    'open'      => 'bg-info text-dark',
    'matched'   => 'bg-warning text-dark',
    'recovered' => 'bg-success',
    'available' => 'bg-info text-dark',
    'claimed'   => 'bg-warning text-dark',
    'handed_over' => 'bg-success',
    default     => 'bg-secondary'
};
?>

<?= getFlash() ?>

<div class="page-header">
  <h2><i class="bi bi-clipboard-data me-2 text-primary"></i>My Reports</h2>
  <p class="text-muted mb-0">Manage all your lost and found item reports.</p>
</div>

<!-- Tabs -->
<ul class="nav nav-tabs mb-4" id="reportTabs">
  <li class="nav-item">
    <a class="nav-link active" data-bs-toggle="tab" href="#lostTab">
      <i class="bi bi-exclamation-circle text-danger me-1"></i>
      Lost Items <span class="badge bg-danger ms-1"><?= count($lost) ?></span>
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-bs-toggle="tab" href="#foundTab">
      <i class="bi bi-check-circle text-success me-1"></i>
      Found Items <span class="badge bg-success ms-1"><?= count($found) ?></span>
    </a>
  </li>
</ul>

<div class="tab-content">
  <!-- Lost Items Tab -->
  <div class="tab-pane fade show active" id="lostTab">
    <?php if (empty($lost)): ?>
      <div class="text-center py-5 text-muted">
        <i class="bi bi-clipboard-x fs-1 d-block mb-3"></i>
        <p>You haven't reported any lost items yet.</p>
        <a href="report_lost.php" class="btn btn-danger">Report a Lost Item</a>
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead>
            <tr><th>Title</th><th>Category</th><th>Location</th><th>Date Lost</th>
                <th>Days Missing</th><th>Matches</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
          <?php foreach ($lost as $item): ?>
            <tr>
              <td class="fw-semibold"><?= htmlspecialchars($item['title']) ?></td>
              <td><span class="category-pill"><?= htmlspecialchars($item['category']) ?></span></td>
              <td><?= htmlspecialchars($item['location']) ?></td>
              <td><?= $item['date_lost'] ?></td>
              <td><?= $item['days_missing'] ?> days</td>
              <td>
                <?php if ($item['potential_matches'] > 0): ?>
                  <span class="badge bg-warning text-dark"><?= $item['potential_matches'] ?> found</span>
                <?php else: ?>
                  <span class="text-muted">—</span>
                <?php endif; ?>
              </td>
              <td><span class="badge <?= $statusBadge($item['status']) ?>"><?= ucfirst($item['status']) ?></span></td>
              <td>
                <form method="POST" class="d-inline">
                  <input type="hidden" name="action"  value="delete_lost">
                  <input type="hidden" name="lost_id" value="<?= $item['lost_id'] ?>">
                  <button type="submit" class="btn btn-sm btn-outline-danger"
                          data-confirm="Delete this lost item report?">
                    <i class="bi bi-trash"></i>
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <!-- Found Items Tab -->
  <div class="tab-pane fade" id="foundTab">
    <?php if (empty($found)): ?>
      <div class="text-center py-5 text-muted">
        <i class="bi bi-clipboard-check fs-1 d-block mb-3"></i>
        <p>You haven't reported any found items yet.</p>
        <a href="report_found.php" class="btn btn-success">Report a Found Item</a>
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead>
            <tr><th>Title</th><th>Category</th><th>Location</th><th>Date Found</th>
                <th>Claims</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
          <?php foreach ($found as $item): ?>
            <tr>
              <td class="fw-semibold"><?= htmlspecialchars($item['title']) ?></td>
              <td><span class="category-pill"><?= htmlspecialchars($item['category']) ?></span></td>
              <td><?= htmlspecialchars($item['location']) ?></td>
              <td><?= $item['date_found'] ?></td>
              <td>
                <?php if ($item['claim_count'] > 0): ?>
                  <span class="badge bg-primary"><?= $item['claim_count'] ?></span>
                <?php else: ?>
                  <span class="text-muted">0</span>
                <?php endif; ?>
              </td>
              <td><span class="badge <?= $statusBadge($item['status']) ?>"><?= ucfirst($item['status']) ?></span></td>
              <td>
                <form method="POST" class="d-inline">
                  <input type="hidden" name="action"   value="delete_found">
                  <input type="hidden" name="found_id" value="<?= $item['found_id'] ?>">
                  <button type="submit" class="btn btn-sm btn-outline-danger"
                          data-confirm="Delete this found item report?">
                    <i class="bi bi-trash"></i>
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php footer_html(); ?>
