<?php
// ─────────────────────────────────────────────────
//  user/report_lost.php  —  Report a Lost Item
// ─────────────────────────────────────────────────
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
requireUser();

$errors = [];
$data   = ['title' => '', 'category' => '', 'description' => '', 'location' => '', 'date_lost' => date('Y-m-d')];
$categories = ['Electronics', 'Stationery', 'Books', 'Clothing', 'Accessories', 'ID/Cards', 'Keys', 'Bag/Wallet', 'Other'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['title']       = trim($_POST['title']       ?? '');
    $data['category']    = trim($_POST['category']    ?? '');
    $data['description'] = trim($_POST['description'] ?? '');
    $data['location']    = trim($_POST['location']    ?? '');
    $data['date_lost']   = trim($_POST['date_lost']   ?? '');

    if ($data['title']       === '') $errors[] = 'Item title is required.';
    if ($data['category']    === '') $errors[] = 'Category is required.';
    if ($data['description'] === '') $errors[] = 'Description is required.';
    if ($data['location']    === '') $errors[] = 'Location is required.';
    if ($data['date_lost']   === '') $errors[] = 'Date lost is required.';

    if (empty($errors)) {
        // INSERT: Report a lost item (dynamic user input handling)
        $stmt = $pdo->prepare("
            INSERT INTO Lost_Items (user_id, title, category, description, location, date_lost, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 'open', NOW())
        ");
        $stmt->execute([
            $_SESSION['user_id'],
            $data['title'], $data['category'], $data['description'],
            $data['location'], $data['date_lost']
        ]);

        setFlash('success', 'Lost item reported successfully! We will look for matches.');
        header('Location: /lost_found/user/dashboard.php'); exit;
    }
}

header_html('Report Lost Item', 'user');
?>

<?= getFlash() ?>

<div class="page-header">
  <h2><i class="bi bi-exclamation-circle text-danger me-2"></i>Report a Lost Item</h2>
  <p class="text-muted mb-0">Fill in the details to help us find your item.</p>
</div>

<div class="row justify-content-center">
  <div class="col-lg-7">
    <div class="card">
      <div class="card-header bg-danger text-white">Lost Item Details</div>
      <div class="card-body p-4">

        <?php if (!empty($errors)): ?>
          <div class="alert alert-danger">
            <ul class="mb-0 ps-3">
              <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
            </ul>
          </div>
        <?php endif; ?>

        <form method="POST" novalidate>
          <div class="mb-3">
            <label class="form-label fw-semibold">Item Title <span class="text-danger">*</span></label>
            <input type="text" name="title" class="form-control"
                   value="<?= htmlspecialchars($data['title']) ?>"
                   placeholder="e.g. Black Laptop Bag" required>
          </div>

          <div class="row mb-3">
            <div class="col-md-6">
              <label class="form-label fw-semibold">Category <span class="text-danger">*</span></label>
              <select name="category" class="form-select" required>
                <option value="">-- Select Category --</option>
                <?php foreach ($categories as $cat): ?>
                  <option value="<?= $cat ?>" <?= $data['category']===$cat?'selected':'' ?>><?= $cat ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Date Lost <span class="text-danger">*</span></label>
              <input type="date" name="date_lost" class="form-control"
                     value="<?= htmlspecialchars($data['date_lost']) ?>"
                     max="<?= date('Y-m-d') ?>" required>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Last Seen Location <span class="text-danger">*</span></label>
            <input type="text" name="location" class="form-control"
                   value="<?= htmlspecialchars($data['location']) ?>"
                   placeholder="e.g. Library, 2nd Floor" required>
          </div>

          <div class="mb-4">
            <label class="form-label fw-semibold">Description <span class="text-danger">*</span></label>
            <textarea name="description" class="form-control" rows="4"
                      data-maxlength="500"
                      placeholder="Describe the item: color, brand, distinguishing features..."
                      required><?= htmlspecialchars($data['description']) ?></textarea>
          </div>

          <div class="d-flex gap-2">
            <button type="submit" class="btn btn-danger fw-semibold px-4">
              <i class="bi bi-send me-2"></i>Submit Report
            </button>
            <a href="/lost_found/user/dashboard.php" class="btn btn-outline-secondary px-4">Cancel</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php footer_html(); ?>
