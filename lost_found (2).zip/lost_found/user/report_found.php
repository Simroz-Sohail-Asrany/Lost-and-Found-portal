<?php
// ─────────────────────────────────────────────────
//  user/report_found.php  —  Report a Found Item
// ─────────────────────────────────────────────────
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
requireUser();

$errors = [];
$data   = ['title' => '', 'category' => '', 'description' => '', 'location' => '', 'date_found' => date('Y-m-d')];
$categories = ['Electronics', 'Stationery', 'Books', 'Clothing', 'Accessories', 'ID/Cards', 'Keys', 'Bag/Wallet', 'Other'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['title']       = trim($_POST['title']       ?? '');
    $data['category']    = trim($_POST['category']    ?? '');
    $data['description'] = trim($_POST['description'] ?? '');
    $data['location']    = trim($_POST['location']    ?? '');
    $data['date_found']  = trim($_POST['date_found']  ?? '');

    if ($data['title']       === '') $errors[] = 'Item title is required.';
    if ($data['category']    === '') $errors[] = 'Category is required.';
    if ($data['description'] === '') $errors[] = 'Description is required.';
    if ($data['location']    === '') $errors[] = 'Location is required.';
    if ($data['date_found']  === '') $errors[] = 'Date found is required.';

    if (empty($errors)) {
        // INSERT: Report a found item
        $stmt = $pdo->prepare("
            INSERT INTO Found_Items (user_id, title, category, description, location, date_found, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 'available', NOW())
        ");
        $stmt->execute([
            $_SESSION['user_id'],
            $data['title'], $data['category'], $data['description'],
            $data['location'], $data['date_found']
        ]);

        setFlash('success', 'Found item reported! The owner will be notified if there is a match.');
        header('Location: /lost_found/user/dashboard.php'); exit;
    }
}

header_html('Report Found Item', 'user');
?>

<?= getFlash() ?>

<div class="page-header">
  <h2><i class="bi bi-check-circle text-success me-2"></i>Report a Found Item</h2>
  <p class="text-muted mb-0">Help reunite an item with its rightful owner.</p>
</div>

<div class="row justify-content-center">
  <div class="col-lg-7">
    <div class="card">
      <div class="card-header bg-success text-white">Found Item Details</div>
      <div class="card-body p-4">

        <?php if (!empty($errors)): ?>
          <div class="alert alert-danger">
            <ul class="mb-0 ps-3">
              <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
            </ul>
          </div>
        <?php endif; ?>

        <form method="POST" novalidate>
          <div class="mb-3">
            <label class="form-label fw-semibold">Item Title <span class="text-danger">*</span></label>
            <input type="text" name="title" class="form-control"
                   value="<?= htmlspecialchars($data['title']) ?>"
                   placeholder="e.g. Blue Water Bottle" required>
          </div>

          <div class="row mb-3">
            <div class="col-md-6">
              <label class="form-label fw-semibold">Category <span class="text-danger">*</span></label>
              <select name="category" class="form-select" required>
                <option value="">-- Select Category --</option>
                <?php foreach ($categories as $cat): ?>
                  <option value="<?= $cat ?>" <?= $data['category']===$cat?'selected':'' ?>><?= $cat ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Date Found <span class="text-danger">*</span></label>
              <input type="date" name="date_found" class="form-control"
                     value="<?= htmlspecialchars($data['date_found']) ?>"
                     max="<?= date('Y-m-d') ?>" required>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Location Found <span class="text-danger">*</span></label>
            <input type="text" name="location" class="form-control"
                   value="<?= htmlspecialchars($data['location']) ?>"
                   placeholder="e.g. Cafeteria, Main Campus" required>
          </div>

          <div class="mb-4">
            <label class="form-label fw-semibold">Description <span class="text-danger">*</span></label>
            <textarea name="description" class="form-control" rows="4"
                      data-maxlength="500"
                      placeholder="Describe the item in detail so the owner can identify it..."
                      required><?= htmlspecialchars($data['description']) ?></textarea>
          </div>

          <div class="d-flex gap-2">
            <button type="submit" class="btn btn-success fw-semibold px-4">
              <i class="bi bi-send me-2"></i>Submit Report
            </button>
            <a href="/lost_found/user/dashboard.php" class="btn btn-outline-secondary px-4">Cancel</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php footer_html(); ?>
