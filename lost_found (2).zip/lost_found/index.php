<?php
// ─────────────────────────────────────────────────
//  index.php  —  Modern Landing Page
// ─────────────────────────────────────────────────
session_start();
require_once __DIR__ . '/includes/db.php';

// Fetch stats for the landing page
$stats = ['lost' => 0, 'found' => 0, 'recovered' => 0];

try {
    $stats['lost'] = $pdo->query("SELECT COUNT(*) FROM Lost_Items")->fetchColumn();
    $stats['found'] = $pdo->query("SELECT COUNT(*) FROM Found_Items")->fetchColumn();
    $stats['recovered'] = $pdo->query("SELECT COUNT(*) FROM Lost_Items WHERE status = 'recovered'")->fetchColumn();
} catch (PDOException $e) { }

// Fetch recent items
$recent_lost = [];
$recent_found = [];
try {
    $recent_lost = $pdo->query("SELECT title, category, location, date_lost FROM Lost_Items WHERE status = 'open' ORDER BY created_at DESC LIMIT 4")->fetchAll();
    $recent_found = $pdo->query("SELECT title, category, location, date_found FROM Found_Items WHERE status = 'available' ORDER BY created_at DESC LIMIT 4")->fetchAll();
} catch (PDOException $e) { }

$is_logged_in = !empty($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | Lost & Found Portal</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="/lost_found/css/style.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light fixed-top">
  <div class="container">
    <a class="navbar-brand" href="/lost_found/index.php">
      <i class="bi bi-search-heart me-2"></i>Lost & Found
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav ms-auto align-items-center">
        <?php if ($is_logged_in): ?>
          <li class="nav-item">
            <a class="nav-link" href="<?= $_SESSION['role'] === 'admin' ? '/lost_found/admin/dashboard.php' : '/lost_found/user/dashboard.php' ?>">
              <i class="bi bi-speedometer2 me-1"></i> Dashboard
            </a>
          </li>
          <li class="nav-item ms-lg-3">
            <a class="btn btn-primary btn-sm fw-bold px-3" href="/lost_found/logout.php">Logout</a>
          </li>
        <?php else: ?>
          <li class="nav-item">
            <a class="nav-link fw-medium" href="/lost_found/login.php">Login</a>
          </li>
          <li class="nav-item ms-lg-3">
            <a class="btn btn-primary btn-sm fw-bold px-3" href="/lost_found/register.php">Get Started</a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero-section text-white py-5">
  <div class="container py-5">
    <div class="row align-items-center py-5">
      <div class="col-lg-7">
        <h1 class="display-3 fw-bold mb-4">Reuniting You with <span class="text-warning">What Matters</span></h1>
        <p class="lead mb-4 opacity-90" style="font-size: 1.2rem;">The smart way to report and find lost items on campus. Our intelligent matching system helps reconnect owners with their belongings quickly and easily.</p>
        <div class="d-flex flex-wrap gap-3">
          <a href="/lost_found/user/report_lost.php" class="btn btn-warning btn-lg px-4 fw-bold">
            <i class="bi bi-exclamation-triangle me-2"></i>Report Lost
          </a>
          <a href="/lost_found/user/report_found.php" class="btn btn-outline-light btn-lg px-4 fw-bold">
            <i class="bi bi-hand-thumbs-up me-2"></i>Report Found
          </a>
        </div>
      </div>
      <div class="col-lg-5 d-none d-lg-block">
        <div class="position-relative">
          <div class="position-absolute top-50 start-50 translate-middle" style="width: 280px; height: 280px; background: rgba(255,255,255,0.1); border-radius: 50%; filter: blur(40px);"></div>
          <div class="glass p-4 rounded-xl">
            <div class="text-center">
              <i class="bi bi-box-seam display-1 mb-3"></i>
              <h4 class="fw-bold">150+</h4>
              <p class="mb-0 opacity-80">Items Reunited</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Stats Section -->
<section class="py-5" style="margin-top: -60px; position: relative; z-index: 10;">
  <div class="container">
    <div class="row g-4">
      <div class="col-md-4">
        <div class="stat-card" style="background: linear-gradient(135deg, #fff 0%, #f8fafc 100%);">
          <div class="stat-icon" style="background: rgba(79, 70, 229, 0.1); color: var(--primary);">
            <i class="bi bi-exclamation-circle"></i>
          </div>
          <div class="stat-num"><?= number_format($stats['lost']) ?></div>
          <div class="stat-label">Items Lost</div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="stat-card" style="background: linear-gradient(135deg, #fff 0%, #f8fafc 100%);">
          <div class="stat-icon" style="background: rgba(16, 185, 129, 0.1); color: var(--success);">
            <i class="bi bi-hand-thumbs-up"></i>
          </div>
          <div class="stat-num" style="background: linear-gradient(135deg, var(--success) 0%, #34d399 100%); -webkit-background-clip: text;"><?= number_format($stats['found']) ?></div>
          <div class="stat-label">Items Found</div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="stat-card" style="background: linear-gradient(135deg, #fff 0%, #f8fafc 100%);">
          <div class="stat-icon" style="background: rgba(245, 158, 11, 0.1); color: var(--warning);">
            <i class="bi bi-arrow-repeat"></i>
          </div>
          <div class="stat-num" style="background: linear-gradient(135deg, var(--warning) 0%, #fbbf24 100%); -webkit-background-clip: text;"><?= number_format($stats['recovered']) ?></div>
          <div class="stat-label">Reunited</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Recent Items -->
<section class="py-5">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-6">
        <div class="d-flex align-items-center justify-content-between mb-4">
          <div>
            <h3 class="fw-bold mb-1">Recent Lost Items</h3>
            <p class="text-muted mb-0">Items reported as lost on campus</p>
          </div>
          <a href="/lost_found/user/search.php" class="btn btn-outline-primary btn-sm">
            View all <i class="bi bi-arrow-right ms-1"></i>
          </a>
        </div>
        <?php if (empty($recent_lost)): ?>
          <div class="card p-5 text-center">
            <i class="bi bi-inbox display-4 text-muted mb-3"></i>
            <p class="text-muted mb-0">No recent lost items reported.</p>
          </div>
        <?php else: ?>
          <?php foreach ($recent_lost as $item): ?>
            <div class="item-card mb-3 border-start border-danger border-4">
              <div class="d-flex justify-content-between align-items-start mb-2">
                <h5 class="fw-bold mb-0"><?= htmlspecialchars($item['title']) ?></h5>
                <span class="category-pill" style="background: rgba(220, 53, 69, 0.1); color: #dc3545;"><?= htmlspecialchars($item['category']) ?></span>
              </div>
              <div class="d-flex gap-3 text-muted small">
                <span><i class="bi bi-geo-alt me-1"></i><?= htmlspecialchars($item['location']) ?></span>
                <span><i class="bi bi-calendar-event me-1"></i><?= date('M d, Y', strtotime($item['date_lost'])) ?></span>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
      <div class="col-lg-6">
        <div class="d-flex align-items-center justify-content-between mb-4">
          <div>
            <h3 class="fw-bold mb-1 text-success">Recent Found Items</h3>
            <p class="text-muted mb-0">Items waiting to be claimed</p>
          </div>
          <a href="/lost_found/user/search.php" class="btn btn-outline-success btn-sm">
            View all <i class="bi bi-arrow-right ms-1"></i>
          </a>
        </div>
        <?php if (empty($recent_found)): ?>
          <div class="card p-5 text-center">
            <i class="bi bi-inbox display-4 text-muted mb-3"></i>
            <p class="text-muted mb-0">No recent found items reported.</p>
          </div>
        <?php else: ?>
          <?php foreach ($recent_found as $item): ?>
            <div class="item-card found mb-3">
              <div class="d-flex justify-content-between align-items-start mb-2">
                <h5 class="fw-bold mb-0"><?= htmlspecialchars($item['title']) ?></h5>
                <span class="category-pill" style="background: rgba(16, 185, 129, 0.1); color: var(--success);"><?= htmlspecialchars($item['category']) ?></span>
              </div>
              <div class="d-flex gap-3 text-muted small">
                <span><i class="bi bi-geo-alt me-1"></i><?= htmlspecialchars($item['location']) ?></span>
                <span><i class="bi bi-calendar-event me-1"></i><?= date('M d, Y', strtotime($item['date_found'])) ?></span>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<!-- How It Works -->
<section class="py-5 bg-light">
  <div class="container">
    <div class="text-center mb-5">
      <h2 class="fw-bold mb-2">How It Works</h2>
      <p class="text-muted">Three simple steps to reunite with your belongings</p>
    </div>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="feature-card">
          <div class="feature-icon">
            <i class="bi bi-pencil-square"></i>
          </div>
          <h4 class="fw-bold mb-2">1. Report It</h4>
          <p class="text-muted mb-0">Fill out a simple form with details about the item you lost or found on campus.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-card">
          <div class="feature-icon">
            <i class="bi bi-cpu"></i>
          </div>
          <h4 class="fw-bold mb-2">2. Smart Match</h4>
          <p class="text-muted mb-0">Our system automatically matches lost reports with found items based on category and location.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-card">
          <div class="feature-icon">
            <i class="bi bi-hand-thumbs-up"></i>
          </div>
          <h4 class="fw-bold mb-2">3. Recover</h4>
          <p class="text-muted mb-0">Once matched and verified, collect your item from the campus office.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CTA Section -->
<section class="py-5">
  <div class="container">
    <div class="card p-5 text-center" style="background: linear-gradient(135deg, var(--primary) 0%, #7c3aed 100%); border: none;">
      <h2 class="fw-bold text-white mb-3">Ready to Get Started?</h2>
      <p class="text-white opacity-90 mb-4">Join thousands of students who have reunited with their belongings.</p>
      <?php if (!$is_logged_in): ?>
        <a href="/lost_found/register.php" class="btn btn-warning btn-lg fw-bold px-5">
          <i class="bi bi-person-plus me-2"></i>Create Account
        </a>
      <?php else: ?>
        <a href="/lost_found/user/dashboard.php" class="btn btn-warning btn-lg fw-bold px-5">
          <i class="bi bi-speedometer2 me-2"></i>Go to Dashboard
        </a>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- Footer -->
<footer class="footer">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-4">
        <h5 class="fw-bold mb-3">
          <i class="bi bi-search-heart me-2"></i>Lost & Found
        </h5>
        <p class="text-muted mb-0">The central hub for reporting lost and found items at FAST NUCES. Helping the campus community reunite with their belongings since 2026.</p>
      </div>
      <div class="col-lg-2">
        <h6 class="fw-bold mb-3 text-uppercase text-muted small">Quick Links</h6>
        <a href="/lost_found/user/search.php" class="d-block">Search Items</a>
        <a href="/lost_found/user/report_lost.php" class="d-block">Report Lost</a>
        <a href="/lost_found/user/report_found.php" class="d-block">Report Found</a>
      </div>
      <div class="col-lg-2">
        <h6 class="fw-bold mb-3 text-uppercase text-muted small">Account</h6>
        <a href="/lost_found/login.php" class="d-block">Login</a>
        <a href="/lost_found/register.php" class="d-block">Register</a>
      </div>
      <div class="col-lg-4">
        <h6 class="fw-bold mb-3 text-uppercase text-muted small">Contact</h6>
        <p class="mb-1" style="color: #94a3b8;"><i class="bi bi-building me-2"></i>FAST NUCES, Karachi</p>
        <p class="mb-1" style="color: #94a3b8;"><i class="bi bi-envelope me-2"></i>lostfound@fast.edu</p>
        <p class="mb-0" style="color: #94a3b8;"><i class="bi bi-telephone me-2"></i>+92 42 111 111 327</p>
      </div>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Navbar scroll effect
  window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });
</script>
</body>
</html>