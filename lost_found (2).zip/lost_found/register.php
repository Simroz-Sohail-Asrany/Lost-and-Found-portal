<?php
// ─────────────────────────────────────────────────
//  register.php  —  New User Registration
// ─────────────────────────────────────────────────
session_start();
require_once __DIR__ . '/includes/db.php';

if (!empty($_SESSION['user_id'])) {
    header('Location: /lost_found/user/dashboard.php'); exit;
}

$errors = [];
$data   = ['name' => '', 'email' => '', 'role' => 'student'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['name']  = trim($_POST['name']  ?? '');
    $data['email'] = trim($_POST['email'] ?? '');
    $data['role']  = in_array($_POST['role'] ?? '', ['student', 'staff']) ? $_POST['role'] : 'student';
    $password      = $_POST['password']  ?? '';
    $confirm       = $_POST['confirm']   ?? '';

    if ($data['name']  === '') $errors[] = 'Full name is required.';
    if ($data['email'] === '' || !filter_var($data['email'], FILTER_VALIDATE_EMAIL))
                                 $errors[] = 'A valid email is required.';
    if (strlen($password) < 6)   $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm)  $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        // Check duplicate email (dynamic input)
        $chk = $pdo->prepare("SELECT user_id FROM Users WHERE email = ?");
        $chk->execute([$data['email']]);
        if ($chk->fetch()) {
            $errors[] = 'This email is already registered.';
        } else {
            // INSERT new user
            $stmt = $pdo->prepare(
                "INSERT INTO Users (name, email, password, role, created_at)
                 VALUES (?, ?, ?, ?, NOW())"
            );
            $stmt->execute([$data['name'], $data['email'], password_hash($password, PASSWORD_DEFAULT), $data['role']]);
            header('Location: /lost_found/login.php?registered=1'); exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Lost & Found Portal</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="/lost_found/css/style.css">
</head>
<body>
<div class="auth-wrapper">
  <div class="auth-card card" style="max-width:480px">
    <div class="card-header">
      <div class="auth-logo"><i class="bi bi-person-plus"></i></div>
      <h4 class="mt-2 fw-bold">Create Account</h4>
      <p class="text-muted small mb-0">Lost &amp; Found Portal — FAST NUCES</p>
    </div>
    <div class="card-body p-4">

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger py-2">
          <ul class="mb-0 ps-3">
            <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="POST" novalidate>
        <div class="mb-3">
          <label class="form-label fw-semibold">Full Name</label>
          <input type="text" name="name" class="form-control"
                 value="<?= htmlspecialchars($data['name']) ?>" placeholder="e.g. Ali Hassan" required>
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold">Email Address</label>
          <input type="email" name="email" class="form-control"
                 value="<?= htmlspecialchars($data['email']) ?>" placeholder="yourname@nu.edu.pk" required>
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold">Role</label>
          <select name="role" class="form-select">
            <option value="student" <?= $data['role']==='student'?'selected':'' ?>>Student</option>
            <option value="staff"   <?= $data['role']==='staff'  ?'selected':'' ?>>Staff</option>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold">Password</label>
          <input type="password" name="password" class="form-control" placeholder="Min. 6 characters" required>
        </div>
        <div class="mb-4">
          <label class="form-label fw-semibold">Confirm Password</label>
          <input type="password" name="confirm" class="form-control" placeholder="Re-enter password" required>
        </div>
        <button type="submit" class="btn btn-success w-100 py-2 fw-semibold">
          <i class="bi bi-check-circle me-2"></i>Register
        </button>
      </form>

      <hr class="my-3">
      <p class="text-center mb-0 small">
        Already have an account?
        <a href="/lost_found/login.php" class="fw-semibold">Login here</a>
      </p>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
