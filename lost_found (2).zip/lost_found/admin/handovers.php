<?php
// ─────────────────────────────────────────────────
//  admin/handovers.php  —  Record Item Handovers
//
//  Demonstrates:
//   • UPDATE with transaction
//   • JOIN across 4 tables
//   • Advanced SQL: CASE, aggregate, subqueries
//   • Dynamic input: filter by status
// ─────────────────────────────────────────────────
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
requireAdmin();

$adminId = $_SESSION['user_id'];

// ── Handle Handover ───────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['handover'])) {
    $claimId = (int)($_POST['claim_id'] ?? 0);
    $remarks = trim($_POST['remarks']   ?? 'Item handed over to owner.');

    if ($claimId > 0) {
        try {
            $pdo->beginTransaction();

            // Get found_id from the claim
            $getClaim = $pdo->prepare("SELECT found_id FROM Claims WHERE claim_id = ? AND status='approved'");
            $getClaim->execute([$claimId]);
            $claimRow = $getClaim->fetch();

            if ($claimRow) {
                // UPDATE Found_Item status to handed_over
                $pdo->prepare("UPDATE Found_Items SET status='handed_over' WHERE found_id = ?")
                    ->execute([$claimRow['found_id']]);

                // UPDATE Lost_Items: mark matching category/user items as recovered
                $upLost = $pdo->prepare("
                    UPDATE Lost_Items li
                    JOIN Claims c ON c.claim_id = ?
                    JOIN Found_Items fi ON fi.found_id = c.found_id
                    SET li.status = 'recovered'
                    WHERE li.user_id = c.user_id
                      AND LOWER(li.category) = LOWER(fi.category)
                      AND li.status = 'open'
                    LIMIT 1
                ");
                $upLost->execute([$claimId]);

                // Log handover as admin action
                $pdo->prepare("
                    INSERT INTO Admin_Actions (admin_id, claim_id, action, remarks, action_date)
                    VALUES (?, ?, 'approved', ?, NOW())
                ")->execute([$adminId, $claimId, "HANDOVER: $remarks"]);
            }

            $pdo->commit();
            setFlash('success', 'Item marked as handed over successfully.');
        } catch (Exception $e) {
            $pdo->rollBack();
            setFlash('danger', 'Error: ' . $e->getMessage());
        }
    }
    header('Location: handovers.php'); exit;
}

// ── Fetch approved claims awaiting handover ───────────────────────────
// JOIN: Claims ↔ Users ↔ Found_Items ↔ Users (reporter)
$pending = $pdo->query("
    SELECT
        c.claim_id,
        cu.name                                   AS claimant_name,
        cu.email                                  AS claimant_email,
        fi.title                                  AS item_title,
        fi.category,
        fi.location,
        DATE_FORMAT(c.created_at,'%d %b %Y')      AS claim_date,
        ru.name                                   AS reporter_name
    FROM Claims c
    JOIN Users cu        ON cu.user_id   = c.user_id
    JOIN Found_Items fi  ON fi.found_id  = c.found_id
    JOIN Users ru        ON ru.user_id   = fi.user_id
    WHERE c.status = 'approved' AND fi.status = 'claimed'
    ORDER BY c.created_at ASC
")->fetchAll();

// ── Handover history ──────────────────────────────────────────────────
// Advanced SQL: aggregate + GROUP BY, CASE
$history = $pdo->query("
    SELECT
        aa.action_id,
        aa.remarks,
        DATE_FORMAT(aa.action_date,'%d %b %Y %H:%i') AS done_at,
        adm.name    AS admin_name,
        cu.name     AS claimant_name,
        fi.title    AS item_title,
        fi.category
    FROM Admin_Actions aa
    JOIN Users adm       ON adm.user_id  = aa.admin_id
    JOIN Claims c        ON c.claim_id   = aa.claim_id
    JOIN Users cu        ON cu.user_id   = c.user_id
    JOIN Found_Items fi  ON fi.found_id  = c.found_id
    WHERE aa.remarks LIKE 'HANDOVER:%'
    ORDER BY aa.action_date DESC
    LIMIT 20
")->fetchAll();

header_html('Handovers', 'admin');
?>

<?= getFlash() ?>

<div class="page-header">
  <h2><i class="bi bi-box-arrow-right me-2 text-primary"></i>Item Handovers</h2>
  <p class="text-muted mb-0">Record the physical handover of approved items to their owners.</p>
</div>

<!-- Pending Handovers -->
<h5 class="fw-bold mb-3">
  Approved Claims — Awaiting Handover
  <span class="badge bg-warning text-dark ms-2"><?= count($pending) ?></span>
</h5>

<?php if (empty($pending)): ?>
  <div class="card text-center p-5 text-muted mb-4">
    <i class="bi bi-inbox fs-1 d-block mb-3"></i>
    <p>No items awaiting handover right now.</p>
    <a href="manage_claims.php" class="btn btn-warning">Review Claims</a>
  </div>
<?php else: ?>
  <div class="row g-3 mb-4">
  <?php foreach ($pending as $p): ?>
    <div class="col-md-6">
      <div class="card border-success">
        <div class="card-header bg-success text-white">
          <strong><?= htmlspecialchars($p['item_title']) ?></strong>
          <span class="category-pill ms-2" style="background:#d4edda;color:#155724;"><?= htmlspecialchars($p['category']) ?></span>
        </div>
        <div class="card-body">
          <div class="row mb-2">
            <div class="col-6">
              <small class="text-muted">Claimant</small><br>
              <strong><?= htmlspecialchars($p['claimant_name']) ?></strong><br>
              <small class="text-muted"><?= htmlspecialchars($p['claimant_email']) ?></small>
            </div>
            <div class="col-6">
              <small class="text-muted">Found at</small><br>
              <?= htmlspecialchars($p['location']) ?><br>
              <small class="text-muted">Reported by <?= htmlspecialchars($p['reporter_name']) ?></small>
            </div>
          </div>
          <form method="POST" class="mt-2">
            <input type="hidden" name="claim_id" value="<?= $p['claim_id'] ?>">
            <div class="input-group">
              <input type="text" name="remarks" class="form-control form-control-sm"
                     placeholder="Remarks (optional)"
                     value="Item handed over to owner.">
              <button type="submit" name="handover"
                      class="btn btn-success btn-sm fw-semibold"
                      data-confirm="Confirm handover of '<?= htmlspecialchars($p['item_title']) ?>' to <?= htmlspecialchars($p['claimant_name']) ?>?">
                <i class="bi bi-box-arrow-right me-1"></i>Mark Handed Over
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
  </div>
<?php endif; ?>

<!-- Handover History -->
<h5 class="fw-bold mb-3">Handover History</h5>
<?php if (empty($history)): ?>
  <p class="text-muted">No handovers recorded yet.</p>
<?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead>
        <tr><th>Item</th><th>Category</th><th>Claimant</th><th>Processed By</th><th>Remarks</th><th>Date</th></tr>
      </thead>
      <tbody>
      <?php foreach ($history as $h): ?>
        <tr>
          <td class="fw-semibold"><?= htmlspecialchars($h['item_title']) ?></td>
          <td><span class="category-pill"><?= htmlspecialchars($h['category']) ?></span></td>
          <td><?= htmlspecialchars($h['claimant_name']) ?></td>
          <td><?= htmlspecialchars($h['admin_name']) ?></td>
          <td class="small text-muted"><?= htmlspecialchars(str_replace('HANDOVER: ', '', $h['remarks'])) ?></td>
          <td class="small"><?= $h['done_at'] ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<?php footer_html(); ?>
