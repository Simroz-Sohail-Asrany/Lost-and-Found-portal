<?php
// ─────────────────────────────────────────────────
//  admin/dashboard.php  —  Admin Home
//  Demonstrates: Aggregate functions (COUNT, AVG),
//  GROUP BY, JOIN across multiple tables
// ─────────────────────────────────────────────────
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
requireAdmin();

// ── System-wide stats ─────────────────────────────────────────────────
// Built-in SQL functions: COUNT, subqueries
$stats = $pdo->query("
    SELECT
        (SELECT COUNT(*) FROM Users       WHERE role <> 'admin')       AS total_users,
        (SELECT COUNT(*) FROM Lost_Items)                               AS total_lost,
        (SELECT COUNT(*) FROM Found_Items)                              AS total_found,
        (SELECT COUNT(*) FROM Claims)                                   AS total_claims,
        (SELECT COUNT(*) FROM Claims WHERE status = 'pending')         AS pending_claims,
        (SELECT COUNT(*) FROM Lost_Items WHERE status = 'recovered')   AS recovered_items,
        (SELECT COUNT(*) FROM Admin_Actions)                            AS total_actions
")->fetch();

// ── Category breakdown (Advanced SQL: combine both tables) ──────────
$categories = $pdo->query("
    SELECT 
        cat.category,
        COALESCE(lost.lost_count, 0) AS lost_count,
        COALESCE(found.found_count, 0) AS found_count
    FROM (
        SELECT category FROM Lost_Items
        UNION
        SELECT category FROM Found_Items
    ) cat
    LEFT JOIN (SELECT category, COUNT(*) as lost_count FROM Lost_Items GROUP BY category) lost ON lost.category = cat.category
    LEFT JOIN (SELECT category, COUNT(*) as found_count FROM Found_Items GROUP BY category) found ON found.category = cat.category
    ORDER BY (COALESCE(lost.lost_count, 0) + COALESCE(found.found_count, 0)) DESC
")->fetchAll();

// ── Recent pending claims (JOIN across 3 tables) ──────────────────────
$pendingClaims = $pdo->query("
    SELECT
        c.claim_id,
        c.status,
        c.created_at,
        u.name          AS claimant_name,
        fi.title        AS item_title,
        fi.category,
        DATE_FORMAT(c.created_at, '%d %b %Y') AS submitted_on
    FROM Claims c
    JOIN Users u        ON u.user_id   = c.user_id
    JOIN Found_Items fi ON fi.found_id = c.found_id
    WHERE c.status = 'pending'
    ORDER BY c.created_at ASC
    LIMIT 5
")->fetchAll();

// ── Recent registrations ───────────────────────────────────────────────
$newUsers = $pdo->query("
    SELECT name, email, role,
           DATE_FORMAT(created_at,'%d %b %Y') AS joined
    FROM Users
    WHERE role <> 'admin'
    ORDER BY created_at DESC
    LIMIT 5
")->fetchAll();

header_html('Admin Dashboard', 'admin');
?>

<?= getFlash() ?>

<div class="page-header d-flex justify-content-between align-items-center">
  <div>
    <h2><i class="bi bi-speedometer2 me-2 text-primary"></i>Admin Dashboard</h2>
    <p class="text-muted mb-0">System overview — Lost &amp; Found Portal</p>
  </div>
  <span class="badge bg-danger fs-6 px-3 py-2">
    <?= $stats['pending_claims'] ?> Pending Claims
  </span>
</div>

<!-- Stats -->
<div class="row g-3 mb-4">
  <div class="col-6 col-md-2">
    <div class="stat-box">
      <div class="stat-num text-primary"><?= $stats['total_users'] ?></div>
      <div class="stat-label">Users</div>
    </div>
  </div>
  <div class="col-6 col-md-2">
    <div class="stat-box">
      <div class="stat-num text-danger"><?= $stats['total_lost'] ?></div>
      <div class="stat-label">Lost Reports</div>
    </div>
  </div>
  <div class="col-6 col-md-2">
    <div class="stat-box">
      <div class="stat-num text-success"><?= $stats['total_found'] ?></div>
      <div class="stat-label">Found Reports</div>
    </div>
  </div>
  <div class="col-6 col-md-2">
    <div class="stat-box">
      <div class="stat-num text-warning"><?= $stats['pending_claims'] ?></div>
      <div class="stat-label">Pending Claims</div>
    </div>
  </div>
  <div class="col-6 col-md-2">
    <div class="stat-box">
      <div class="stat-num text-success"><?= $stats['recovered_items'] ?></div>
      <div class="stat-label">Recovered</div>
    </div>
  </div>
  <div class="col-6 col-md-2">
    <div class="stat-box">
      <div class="stat-num text-secondary"><?= $stats['total_actions'] ?></div>
      <div class="stat-label">Admin Actions</div>
    </div>
  </div>
</div>

<div class="row g-4">
  <!-- Category Breakdown -->
  <div class="col-lg-5">
    <div class="card h-100">
      <div class="card-header bg-primary text-white">
        <i class="bi bi-bar-chart me-2"></i>Items by Category
      </div>
      <div class="card-body p-0">
        <table class="table mb-0">
          <thead><tr><th>Category</th><th>Lost</th><th>Found</th><th>Total</th></tr></thead>
          <tbody>
          <?php foreach ($categories as $cat): ?>
            <tr>
              <td><span class="category-pill"><?= htmlspecialchars($cat['category']) ?></span></td>
              <td><span class="badge bg-danger-subtle text-danger"><?= $cat['lost_count'] ?></span></td>
              <td><span class="badge bg-success-subtle text-success"><?= $cat['found_count'] ?></span></td>
              <td class="fw-bold"><?= $cat['lost_count'] + $cat['found_count'] ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Pending Claims -->
  <div class="col-lg-7">
    <div class="card h-100">
      <div class="card-header bg-warning text-dark d-flex justify-content-between align-items-center">
        <span><i class="bi bi-hourglass-split me-2"></i>Pending Claims</span>
        <a href="/lost_found/admin/manage_claims.php" class="btn btn-sm btn-dark">View All</a>
      </div>
      <div class="card-body p-0">
        <?php if (empty($pendingClaims)): ?>
          <div class="p-4 text-center text-muted">No pending claims. 🎉</div>
        <?php else: ?>
          <table class="table table-hover mb-0">
            <thead><tr><th>Claimant</th><th>Item</th><th>Category</th><th>Submitted</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($pendingClaims as $c): ?>
              <tr>
                <td><?= htmlspecialchars($c['claimant_name']) ?></td>
                <td><?= htmlspecialchars($c['item_title']) ?></td>
                <td><span class="category-pill"><?= htmlspecialchars($c['category']) ?></span></td>
                <td><?= $c['submitted_on'] ?></td>
                <td>
                  <a href="/lost_found/admin/manage_claims.php?claim_id=<?= $c['claim_id'] ?>"
                     class="btn btn-sm btn-outline-primary">Review</a>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Recent Users -->
  <div class="col-12">
    <div class="card">
      <div class="card-header bg-secondary text-white d-flex justify-content-between align-items-center">
        <span><i class="bi bi-people me-2"></i>Recent User Registrations</span>
        <a href="/lost_found/admin/manage_reports.php" class="btn btn-sm btn-light">All Reports</a>
      </div>
      <div class="card-body p-0">
        <table class="table table-hover mb-0">
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th></tr></thead>
          <tbody>
          <?php foreach ($newUsers as $u): ?>
            <tr>
              <td><?= htmlspecialchars($u['name']) ?></td>
              <td><?= htmlspecialchars($u['email']) ?></td>
              <td><span class="badge bg-secondary"><?= ucfirst($u['role']) ?></span></td>
              <td><?= $u['joined'] ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php footer_html(); ?>
