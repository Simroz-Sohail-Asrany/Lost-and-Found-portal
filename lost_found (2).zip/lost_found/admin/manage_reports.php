<?php
// ─────────────────────────────────────────────────
//  admin/manage_reports.php  —  View All Reports
//
//  Demonstrates:
//   • JOIN: Lost_Items/Found_Items ↔ Users
//   • Advanced SQL: UNION ALL, ORDER BY, LIMIT
//   • Built-in functions: COUNT, DATE_FORMAT, UPPER
//   • Dynamic user input: search/filter
//   • Admin DELETE
// ─────────────────────────────────────────────────
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
requireAdmin();

// ── Handle Delete ─────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'] ?? '';
    $id   = (int)($_POST['id'] ?? 0);
    if ($type === 'lost' && $id > 0) {
        $pdo->prepare("DELETE FROM Lost_Items WHERE lost_id = ?")->execute([$id]);
        setFlash('success', 'Lost item report deleted.');
    } elseif ($type === 'found' && $id > 0) {
        $pdo->prepare("DELETE FROM Found_Items WHERE found_id = ?")->execute([$id]);
        setFlash('success', 'Found item report deleted.');
    }
    header('Location: manage_reports.php'); exit;
}

// ── Dynamic filters (user input) ──────────────────────────────────────
$tab      = in_array($_GET['tab'] ?? '', ['lost','found']) ? $_GET['tab'] : 'lost';
$keyword  = trim($_GET['keyword']  ?? '');
$category = trim($_GET['category'] ?? '');
$status   = trim($_GET['status']   ?? '');
$categories = ['Electronics','Stationery','Books','Clothing','Accessories','ID/Cards','Keys','Bag/Wallet','Other'];

// ── Build query based on active tab ──────────────────────────────────
if ($tab === 'lost') {
    // JOIN: Lost_Items ↔ Users
    $sql    = "SELECT li.lost_id  AS id, li.title, li.category, li.location,
                      li.date_lost AS item_date, li.status,
                      u.name AS reporter,
                      DATE_FORMAT(li.created_at,'%d %b %Y') AS reported_on
               FROM Lost_Items li
               JOIN Users u ON u.user_id = li.user_id WHERE 1=1";
    $params = [];
    if ($keyword  !== '') { $sql .= " AND (li.title LIKE ? OR li.description LIKE ?)"; $l="%$keyword%"; $params[]=$l;$params[]=$l; }
    if ($category !== '') { $sql .= " AND li.category = ?"; $params[] = $category; }
    if ($status   !== '') { $sql .= " AND li.status   = ?"; $params[] = $status; }
    $sql .= " ORDER BY li.created_at DESC";
    $statusOpts = ['open','matched','recovered'];
} else {
    // JOIN: Found_Items ↔ Users
    $sql    = "SELECT fi.found_id AS id, fi.title, fi.category, fi.location,
                      fi.date_found AS item_date, fi.status,
                      u.name AS reporter,
                      DATE_FORMAT(fi.created_at,'%d %b %Y') AS reported_on
               FROM Found_Items fi
               JOIN Users u ON u.user_id = fi.user_id WHERE 1=1";
    $params = [];
    if ($keyword  !== '') { $sql .= " AND (fi.title LIKE ? OR fi.description LIKE ?)"; $l="%$keyword%"; $params[]=$l;$params[]=$l; }
    if ($category !== '') { $sql .= " AND fi.category = ?"; $params[] = $category; }
    if ($status   !== '') { $sql .= " AND fi.status   = ?"; $params[] = $status; }
    $sql .= " ORDER BY fi.created_at DESC";
    $statusOpts = ['available','claimed','handed_over'];
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

// ── Summary counts (Advanced SQL: aggregate) ──────────────────────────
$summary = $pdo->query("
    SELECT
        (SELECT COUNT(*) FROM Lost_Items  WHERE status='open')        AS open_lost,
        (SELECT COUNT(*) FROM Lost_Items  WHERE status='recovered')   AS recovered_lost,
        (SELECT COUNT(*) FROM Found_Items WHERE status='available')   AS avail_found,
        (SELECT COUNT(*) FROM Found_Items WHERE status='handed_over') AS handed_found
")->fetch();

header_html('All Reports', 'admin');

$badgeMap = ['open'=>'bg-info text-dark','matched'=>'bg-warning text-dark','recovered'=>'bg-success',
             'available'=>'bg-info text-dark','claimed'=>'bg-warning text-dark','handed_over'=>'bg-success'];
?>

<?= getFlash() ?>

<div class="page-header">
  <h2><i class="bi bi-list-ul me-2 text-primary"></i>All Reports</h2>
  <p class="text-muted mb-0">Browse and manage all lost &amp; found reports in the system.</p>
</div>

<!-- Mini Stats -->
<div class="row g-2 mb-3">
  <div class="col-6 col-md-3"><div class="stat-box py-2"><div class="stat-num text-info"><?= $summary['open_lost'] ?></div><div class="stat-label">Open Lost</div></div></div>
  <div class="col-6 col-md-3"><div class="stat-box py-2"><div class="stat-num text-success"><?= $summary['recovered_lost'] ?></div><div class="stat-label">Recovered</div></div></div>
  <div class="col-6 col-md-3"><div class="stat-box py-2"><div class="stat-num text-info"><?= $summary['avail_found'] ?></div><div class="stat-label">Available Found</div></div></div>
  <div class="col-6 col-md-3"><div class="stat-box py-2"><div class="stat-num text-success"><?= $summary['handed_found'] ?></div><div class="stat-label">Handed Over</div></div></div>
</div>

<!-- Tabs -->
<ul class="nav nav-tabs mb-3">
  <li class="nav-item">
    <a class="nav-link <?= $tab==='lost'?'active':'' ?>" href="?tab=lost">
      <i class="bi bi-exclamation-circle text-danger me-1"></i>Lost Items
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?= $tab==='found'?'active':'' ?>" href="?tab=found">
      <i class="bi bi-check-circle text-success me-1"></i>Found Items
    </a>
  </li>
</ul>

<!-- Filters -->
<div class="card mb-3">
  <div class="card-body py-2">
    <form method="GET" class="row g-2 align-items-end">
      <input type="hidden" name="tab" value="<?= $tab ?>">
      <div class="col-md-4">
        <input type="text" name="keyword" class="form-control form-control-sm"
               placeholder="Search keyword…" value="<?= htmlspecialchars($keyword) ?>">
      </div>
      <div class="col-md-3">
        <select name="category" class="form-select form-select-sm">
          <option value="">All Categories</option>
          <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat ?>" <?= $category===$cat?'selected':'' ?>><?= $cat ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3">
        <select name="status" class="form-select form-select-sm">
          <option value="">All Statuses</option>
          <?php foreach ($statusOpts as $st): ?>
            <option value="<?= $st ?>" <?= $status===$st?'selected':'' ?>><?= ucfirst(str_replace('_',' ',$st)) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2 d-flex gap-1">
        <button type="submit" class="btn btn-primary btn-sm w-100">Filter</button>
        <a href="?tab=<?= $tab ?>" class="btn btn-outline-secondary btn-sm w-100">Clear</a>
      </div>
    </form>
  </div>
</div>

<div class="mb-2 text-muted small"><?= count($rows) ?> record(s)</div>

<?php if (empty($rows)): ?>
  <div class="card text-center p-4 text-muted">
    <i class="bi bi-inbox fs-2 d-block mb-2"></i>No reports match your filters.
  </div>
<?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead>
        <tr>
          <th>#</th><th>Title</th><th>Category</th><th>Location</th>
          <th>Date</th><th>Reporter</th><th>Status</th><th>Delete</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($rows as $i => $r): ?>
        <tr>
          <td class="text-muted small"><?= $i + 1 ?></td>
          <td class="fw-semibold"><?= htmlspecialchars($r['title']) ?></td>
          <td><span class="category-pill"><?= htmlspecialchars($r['category']) ?></span></td>
          <td class="small"><?= htmlspecialchars($r['location']) ?></td>
          <td class="small"><?= $r['item_date'] ?></td>
          <td class="small"><?= htmlspecialchars($r['reporter']) ?></td>
          <td>
            <span class="badge <?= $badgeMap[$r['status']] ?? 'bg-secondary' ?>">
              <?= ucfirst(str_replace('_',' ',$r['status'])) ?>
            </span>
          </td>
          <td>
            <form method="POST" class="d-inline">
              <input type="hidden" name="type" value="<?= $tab ?>">
              <input type="hidden" name="id"   value="<?= $r['id'] ?>">
              <button type="submit" class="btn btn-sm btn-outline-danger"
                      data-confirm="Permanently delete this report?">
                <i class="bi bi-trash"></i>
              </button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<?php footer_html(); ?>
