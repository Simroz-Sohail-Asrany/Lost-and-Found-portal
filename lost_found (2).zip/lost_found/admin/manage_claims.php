<?php
// ─────────────────────────────────────────────────
//  admin/manage_claims.php  —  Review & Act on Claims
//
//  Demonstrates:
//   • TRANSACTION: approve claim atomically updates
//     Claims + Found_Items + Admin_Actions
//   • Advanced SQL: JOIN across 4 tables
//   • UPDATE with WHERE
//   • Built-in: NOW(), DATE_FORMAT, DATEDIFF
// ─────────────────────────────────────────────────
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
requireAdmin();

$adminId = $_SESSION['user_id'];

// ── Handle Approve / Reject ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $claimId = (int)($_POST['claim_id'] ?? 0);
    $action  = $_POST['action'];
    $remarks = trim($_POST['remarks'] ?? '');

    if ($claimId > 0 && in_array($action, ['approved', 'rejected'])) {
        try {
            // ── TRANSACTION BEGIN ─────────────────────────────────────
            $pdo->beginTransaction();

            // 1. Update Claim status
            $upClaim = $pdo->prepare("UPDATE Claims SET status = ? WHERE claim_id = ?");
            $upClaim->execute([$action, $claimId]);

            if ($action === 'approved') {
                // 2. Mark the Found Item as 'claimed'
                $upItem = $pdo->prepare("
                    UPDATE Found_Items SET status = 'claimed'
                    WHERE found_id = (SELECT found_id FROM Claims WHERE claim_id = ?)
                ");
                $upItem->execute([$claimId]);
            }

            // 3. Log Admin Action
            $logAction = $pdo->prepare("
                INSERT INTO Admin_Actions (admin_id, claim_id, action, remarks, action_date)
                VALUES (?, ?, ?, ?, NOW())
            ");
            $logAction->execute([$adminId, $claimId, $action, $remarks]);

            // ── TRANSACTION COMMIT ────────────────────────────────────
            $pdo->commit();

            $msg = $action === 'approved' ? 'Claim approved successfully.' : 'Claim rejected.';
            setFlash('success', $msg);
        } catch (Exception $e) {
            $pdo->rollBack();
            setFlash('danger', 'Error processing claim: ' . $e->getMessage());
        }
    }
    header('Location: manage_claims.php'); exit;
}

// ── Filter by status (dynamic user input) ─────────────────────────────
$filterStatus = $_GET['status'] ?? 'pending';
$validStatus  = ['pending', 'approved', 'rejected', 'all'];
if (!in_array($filterStatus, $validStatus)) $filterStatus = 'pending';

// ── Fetch Claims with JOIN ─────────────────────────────────────────────
// JOIN: Claims ↔ Users (claimant) ↔ Found_Items ↔ Users (reporter)
$sql    = "
    SELECT
        c.claim_id,
        c.proof,
        c.status,
        c.created_at,
        cu.name                                 AS claimant_name,
        cu.email                                AS claimant_email,
        fi.found_id,
        fi.title                                AS item_title,
        fi.category,
        fi.location                             AS item_location,
        fi.description                          AS item_desc,
        ru.name                                 AS reporter_name,
        DATE_FORMAT(c.created_at,'%d %b %Y')    AS submitted_on,
        DATEDIFF(NOW(), c.created_at)           AS waiting_days
    FROM Claims c
    JOIN Users cu        ON cu.user_id   = c.user_id
    JOIN Found_Items fi  ON fi.found_id  = c.found_id
    JOIN Users ru        ON ru.user_id   = fi.user_id
";
$params = [];
if ($filterStatus !== 'all') {
    $sql .= " WHERE c.status = ?";
    $params[] = $filterStatus;
}
$sql .= " ORDER BY c.created_at ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$claims = $stmt->fetchAll();

// ── Highlight a specific claim if linked from dashboard ───────────────
$highlightId = (int)($_GET['claim_id'] ?? 0);

header_html('Manage Claims', 'admin');
?>

<?= getFlash() ?>

<div class="page-header d-flex justify-content-between align-items-center">
  <div>
    <h2><i class="bi bi-clipboard-check me-2 text-primary"></i>Manage Claims</h2>
    <p class="text-muted mb-0">Review, approve, or reject submitted claims.</p>
  </div>
</div>

<!-- Status Filter -->
<div class="btn-group mb-4">
  <?php foreach (['pending'=>'warning','approved'=>'success','rejected'=>'danger','all'=>'secondary'] as $s=>$cls): ?>
    <a href="?status=<?= $s ?>"
       class="btn btn-<?= $filterStatus===$s ? $cls : 'outline-'.$cls ?>">
      <?= ucfirst($s) ?>
    </a>
  <?php endforeach; ?>
</div>

<div class="mb-2 text-muted small"><?= count($claims) ?> claim(s)</div>

<?php if (empty($claims)): ?>
  <div class="card text-center p-5 text-muted">
    <i class="bi bi-check2-circle fs-1 d-block mb-3"></i>
    <p>No <?= $filterStatus ?> claims found.</p>
  </div>
<?php endif; ?>

<?php foreach ($claims as $c):
  $isHighlight = ($highlightId === (int)$c['claim_id']);
  $borderClass = $isHighlight ? 'border-primary border-2' : '';
?>
<div class="card mb-3 <?= $borderClass ?>" id="claim-<?= $c['claim_id'] ?>">
  <div class="card-header d-flex justify-content-between align-items-center
    <?= $c['status']==='pending'?'bg-warning text-dark':($c['status']==='approved'?'bg-success text-white':'bg-danger text-white') ?>">
    <div>
      <strong>Claim #<?= $c['claim_id'] ?></strong>
      &nbsp;·&nbsp; <?= htmlspecialchars($c['item_title']) ?>
      <span class="category-pill ms-2"><?= htmlspecialchars($c['category']) ?></span>
    </div>
    <div class="text-end small">
      Submitted <?= $c['submitted_on'] ?> (<?= $c['waiting_days'] ?> days ago)
    </div>
  </div>

  <div class="card-body">
    <div class="row">
      <!-- Item Info -->
      <div class="col-md-4">
        <h6 class="fw-bold text-muted">Item Details</h6>
        <p class="mb-1"><i class="bi bi-geo-alt me-1"></i><?= htmlspecialchars($c['item_location']) ?></p>
        <p class="mb-1 small text-muted"><?= htmlspecialchars(mb_substr($c['item_desc'], 0, 120)) ?>…</p>
        <p class="mb-0 small"><i class="bi bi-person me-1"></i>Reporter: <strong><?= htmlspecialchars($c['reporter_name']) ?></strong></p>
      </div>

      <!-- Claimant Info -->
      <div class="col-md-4">
        <h6 class="fw-bold text-muted">Claimant</h6>
        <p class="mb-1"><i class="bi bi-person-circle me-1"></i><?= htmlspecialchars($c['claimant_name']) ?></p>
        <p class="mb-1 small text-muted"><?= htmlspecialchars($c['claimant_email']) ?></p>
      </div>

      <!-- Proof -->
      <div class="col-md-4">
        <h6 class="fw-bold text-muted">Proof of Ownership</h6>
        <p class="small mb-0"><?= nl2br(htmlspecialchars($c['proof'])) ?></p>
      </div>
    </div>

    <?php if ($c['status'] === 'pending'): ?>
    <hr>
    <div class="row g-2 align-items-end">
      <!-- APPROVE -->
      <div class="col-md-6">
        <form method="POST">
          <input type="hidden" name="claim_id" value="<?= $c['claim_id'] ?>">
          <input type="hidden" name="action"   value="approved">
          <div class="input-group">
            <input type="text" name="remarks" class="form-control form-control-sm"
                   placeholder="Remarks (optional)">
            <button type="submit" class="btn btn-success btn-sm fw-semibold"
                    data-confirm="Approve this claim? The item will be marked as Claimed.">
              <i class="bi bi-check-circle me-1"></i>Approve
            </button>
          </div>
        </form>
      </div>
      <!-- REJECT -->
      <div class="col-md-6">
        <form method="POST">
          <input type="hidden" name="claim_id" value="<?= $c['claim_id'] ?>">
          <input type="hidden" name="action"   value="rejected">
          <div class="input-group">
            <input type="text" name="remarks" class="form-control form-control-sm"
                   placeholder="Reason for rejection">
            <button type="submit" class="btn btn-danger btn-sm fw-semibold"
                    data-confirm="Reject this claim?">
              <i class="bi bi-x-circle me-1"></i>Reject
            </button>
          </div>
        </form>
      </div>
    </div>
    <?php else: ?>
      <div class="mt-2">
        <span class="badge <?= $c['status']==='approved'?'bg-success':'bg-danger' ?> fs-6">
          <?= ucfirst($c['status']) ?>
        </span>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php endforeach; ?>

<?php
if ($highlightId > 0) {
    echo "<script>
      document.addEventListener('DOMContentLoaded',function(){
        var el = document.getElementById('claim-{$highlightId}');
        if(el) el.scrollIntoView({behavior:'smooth',block:'center'});
      });
    </script>";
}
footer_html();
?>
