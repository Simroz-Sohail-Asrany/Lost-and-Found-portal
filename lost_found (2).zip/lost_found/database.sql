-- ================================================================
--  University Lost & Found Portal — Database Schema
--  CS 2005: Database Systems
--  FAST NUCES | Spring 2026
-- ================================================================

CREATE DATABASE IF NOT EXISTS db_project
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_project;

-- ────────────────────────────────────────────────────────────────
--  DROP TABLES (in order of dependencies)
-- ────────────────────────────────────────────────────────────────
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS Matches;
DROP TABLE IF EXISTS Admin_Actions;
DROP TABLE IF EXISTS Claims;
DROP TABLE IF EXISTS Found_Items;
DROP TABLE IF EXISTS Lost_Items;
DROP TABLE IF EXISTS Users;
SET FOREIGN_KEY_CHECKS = 1;

-- ────────────────────────────────────────────────────────────────
--  TABLE 1: Users
-- ────────────────────────────────────────────────────────────────
CREATE TABLE Users (
    user_id    INT          NOT NULL AUTO_INCREMENT,
    name       VARCHAR(100) NOT NULL,
    email      VARCHAR(150) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,           -- bcrypt hash
    role       ENUM('student','staff','admin') NOT NULL DEFAULT 'student',
    created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id),
    INDEX idx_email (email),
    INDEX idx_role  (role)
);

-- ────────────────────────────────────────────────────────────────
--  TABLE 2: Lost_Items
-- ────────────────────────────────────────────────────────────────
CREATE TABLE Lost_Items (
    lost_id     INT          NOT NULL AUTO_INCREMENT,
    user_id     INT          NOT NULL,
    title       VARCHAR(150) NOT NULL,
    category    VARCHAR(50)  NOT NULL,
    description TEXT         NOT NULL,
    location    VARCHAR(150) NOT NULL,
    date_lost   DATE         NOT NULL,
    status      ENUM('open','matched','recovered') NOT NULL DEFAULT 'open',
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (lost_id),
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    INDEX idx_category (category),
    INDEX idx_status   (status)
);

-- ────────────────────────────────────────────────────────────────
--  TABLE 3: Found_Items
-- ────────────────────────────────────────────────────────────────
CREATE TABLE Found_Items (
    found_id    INT          NOT NULL AUTO_INCREMENT,
    user_id     INT          NOT NULL,
    title       VARCHAR(150) NOT NULL,
    category    VARCHAR(50)  NOT NULL,
    description TEXT         NOT NULL,
    location    VARCHAR(150) NOT NULL,
    date_found  DATE         NOT NULL,
    status      ENUM('available','claimed','handed_over') NOT NULL DEFAULT 'available',
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (found_id),
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    INDEX idx_category (category),
    INDEX idx_status   (status)
);

-- ────────────────────────────────────────────────────────────────
--  TABLE 4: Claims
-- ────────────────────────────────────────────────────────────────
CREATE TABLE Claims (
    claim_id   INT  NOT NULL AUTO_INCREMENT,
    user_id    INT  NOT NULL,
    found_id   INT  NOT NULL,
    proof      TEXT NOT NULL,
    status     ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (claim_id),
    FOREIGN KEY (user_id)  REFERENCES Users(user_id)      ON DELETE CASCADE,
    FOREIGN KEY (found_id) REFERENCES Found_Items(found_id) ON DELETE CASCADE,
    UNIQUE KEY uq_user_claim (user_id, found_id),    -- one claim per user per item
    INDEX idx_status (status)
);

-- ────────────────────────────────────────────────────────────────
--  TABLE 5: Admin_Actions
-- ────────────────────────────────────────────────────────────────
CREATE TABLE Admin_Actions (
    action_id   INT  NOT NULL AUTO_INCREMENT,
    admin_id    INT  NOT NULL,
    claim_id    INT  NOT NULL,
    action      ENUM('approved','rejected') NOT NULL,
    remarks     TEXT,
    action_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (action_id),
    FOREIGN KEY (admin_id) REFERENCES Users(user_id)  ON DELETE CASCADE,
    FOREIGN KEY (claim_id) REFERENCES Claims(claim_id) ON DELETE CASCADE
);

-- ────────────────────────────────────────────────────────────────
--  TABLE 6: Matches
-- ────────────────────────────────────────────────────────────────
CREATE TABLE Matches (
    match_id    INT NOT NULL AUTO_INCREMENT,
    lost_id     INT NOT NULL,
    found_id    INT NOT NULL,
    match_score TINYINT NOT NULL DEFAULT 1,   -- 1=category match, 2=location+category
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (match_id),
    FOREIGN KEY (lost_id)  REFERENCES Lost_Items(lost_id)   ON DELETE CASCADE,
    FOREIGN KEY (found_id) REFERENCES Found_Items(found_id) ON DELETE CASCADE,
    UNIQUE KEY uq_match (lost_id, found_id)
);

-- ================================================================
--  SAMPLE DATA
-- ================================================================

-- Admin user (password: admin123)
INSERT INTO Users (name, email, password, role) VALUES
('Admin User', 'admin@nu.edu.pk',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Sample students (password: password)
INSERT INTO Users (name, email, password, role) VALUES
('Ali Hassan',   'ali@nu.edu.pk',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student'),
('Sara Ahmed',   'sara@nu.edu.pk',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student'),
('Zainab Khan',  'zainab@nu.edu.pk', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student');

-- Sample Lost Items
INSERT INTO Lost_Items (user_id, title, category, description, location, date_lost) VALUES
(2, 'Black HP Laptop Bag',    'Bag/Wallet',  'Black backpack with silver zipper, HP sticker on front', 'Library 2nd Floor',  '2026-04-15'),
(2, 'Blue Casio Calculator',  'Electronics', 'Blue Casio FX-991 scientific calculator',                 'Lab Block C',        '2026-04-18'),
(3, 'Samsung Galaxy Earbuds', 'Electronics', 'White Samsung wireless earbuds in black case',            'Cafeteria',          '2026-04-20'),
(4, 'FAST Student ID Card',   'ID/Cards',    'Student ID, name: Zainab Khan, Reg: 24K-0965',            'Main Entrance Gate',  '2026-04-21');

-- Sample Found Items
INSERT INTO Found_Items (user_id, title, category, description, location, date_found) VALUES
(3, 'Black Backpack',       'Bag/Wallet',  'Black bag found near library entrance, contains notebooks', 'Library Entrance',  '2026-04-16'),
(4, 'Scientific Calculator','Electronics', 'Blue calculator found on bench in lab',                     'Lab Block C',       '2026-04-19'),
(2, 'White Earbuds Case',   'Electronics', 'White wireless earbuds case found in cafeteria',            'Cafeteria',         '2026-04-20'),
(3, 'University ID Card',   'ID/Cards',    'FAST student ID card found at main gate',                   'Main Gate Security','2026-04-21');
