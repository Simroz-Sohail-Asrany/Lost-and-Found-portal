<?php
require_once __DIR__ . '/includes/db.php';

echo "<h1>Database Debugger</h1>";
echo "<strong>Current Database:</strong> " . DB_NAME . "<br><br>";

try {
    echo "<h3>Tables in " . DB_NAME . ":</h3>";
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    
    if (empty($tables)) {
        echo "<p style='color:red'>No tables found! Your database is empty.</p>";
    } else {
        echo "<ul>";
        foreach ($tables as $table) {
            echo "<li><strong>$table</strong>";
            $columns = $pdo->query("DESCRIBE $table")->fetchAll();
            echo "<ul>";
            foreach ($columns as $col) {
                echo "<li>{$col['Field']} ({$col['Type']})</li>";
            }
            echo "</ul></li>";
        }
        echo "</ul>";
    }
} catch (Exception $e) {
    echo "<p style='color:red'>Error: " . $e->getMessage() . "</p>";
}
?>
