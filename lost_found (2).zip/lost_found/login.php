<?php
// ─────────────────────────────────────────────────
//  index.php  —  Login Page
// ─────────────────────────────────────────────────
session_start();
require_once __DIR__ . '/includes/db.php';

// Already logged in → redirect
if (!empty($_SESSION['user_id'])) {
    $loc = $_SESSION['role'] === 'admin' ? '/lost_found/admin/dashboard.php' : '/lost_found/user/dashboard.php';
    header("Location: $loc"); exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']    ?? '');
    $password =       $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Please fill in all fields.';
    } else {
        // Parameterised query — dynamic user input handling
        $stmt = $pdo->prepare("SELECT user_id, name, email, password, role FROM Users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['name']    = $user['name'];
            $_SESSION['email']   = $user['email'];
            $_SESSION['role']    = $user['role'];

            $loc = $user['role'] === 'admin' ? '/lost_found/admin/dashboard.php' : '/lost_found/user/dashboard.php';
            header("Location: $loc"); exit;
        } else {
            $error = 'Invalid email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Lost & Found Portal</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="/lost_found/css/style.css">
</head>
<body>
<div class="auth-wrapper">
  <div class="auth-card card">
    <div class="card-header">
      <div class="auth-logo"><a href="/lost_found/index.php" class="text-decoration-none"><i class="bi bi-search-heart"></i></a></div>
      <h4 class="mt-2 fw-bold">Lost &amp; Found Portal</h4>
      <p class="text-muted small mb-0">FAST NUCES — University Campus</p>
    </div>
    <div class="card-body p-4">

      <?php if ($error): ?>
        <div class="alert alert-danger py-2"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="POST" novalidate>
        <div class="mb-3">
          <label class="form-label fw-semibold">Email Address</label>
          <div class="input-group">
            <span class="input-group-text"><i class="bi bi-envelope"></i></span>
            <input type="email" name="email" class="form-control"
                   placeholder="yourname@nu.edu.pk"
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
          </div>
        </div>
        <div class="mb-4">
          <label class="form-label fw-semibold">Password</label>
          <div class="input-group">
            <span class="input-group-text"><i class="bi bi-lock"></i></span>
            <input type="password" name="password" class="form-control" placeholder="••••••••" required>
          </div>
        </div>
        <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
          <i class="bi bi-box-arrow-in-right me-2"></i>Login
        </button>
      </form>

      <hr class="my-3">
      <p class="text-center mb-0 small">
        Don't have an account?
        <a href="/lost_found/register.php" class="fw-semibold">Register here</a>
      </p>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="/lost_found/js/main.js"></script>
</body>
</html>
