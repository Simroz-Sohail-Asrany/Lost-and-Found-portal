// =============================================
//  University Lost & Found Portal — main.js
// =============================================

// Suppress common browser extension noise (e.g., Dashlane, Grammarly)
// Error: "A listener indicated an asynchronous response by returning true..."
window.addEventListener('unhandledrejection', function (event) {
    if (event.reason && event.reason.message && event.reason.message.includes('A listener indicated an asynchronous response')) {
        event.preventDefault();
    }
});

// Auto-dismiss alerts after 4 seconds
document.addEventListener('DOMContentLoaded', function () {
    setTimeout(function () {
        document.querySelectorAll('.alert.alert-success, .alert.alert-danger').forEach(function (el) {
            var alert = bootstrap.Alert.getOrCreateInstance(el);
            alert.close();
        });
    }, 4000);

    // Preview image filename on file input change
    document.querySelectorAll('input[type="file"]').forEach(function (input) {
        input.addEventListener('change', function () {
            var label = this.nextElementSibling;
            if (label && label.classList.contains('form-label')) {
                label.textContent = this.files[0] ? this.files[0].name : 'Choose file';
            }
        });
    });

    // Confirm before delete
    document.querySelectorAll('[data-confirm]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            if (!confirm(this.dataset.confirm || 'Are you sure?')) {
                e.preventDefault();
            }
        });
    });

    // Live character count for textareas with data-maxlength
    document.querySelectorAll('textarea[data-maxlength]').forEach(function (ta) {
        var max = parseInt(ta.dataset.maxlength);
        var counter = document.createElement('small');
        counter.className = 'text-muted';
        counter.textContent = '0 / ' + max;
        ta.parentNode.appendChild(counter);
        ta.addEventListener('input', function () {
            counter.textContent = this.value.length + ' / ' + max;
            counter.className = this.value.length > max * 0.9 ? 'text-danger' : 'text-muted';
        });
    });
});
