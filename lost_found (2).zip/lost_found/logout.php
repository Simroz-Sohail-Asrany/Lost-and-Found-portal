<?php
session_start();
session_destroy();
header('Location: /lost_found/login.php');
exit;
