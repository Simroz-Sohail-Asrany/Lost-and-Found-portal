<?php
// Call this at the top of every page: header_html($title, $role)
function header_html(string $title, string $role = 'user') {
    $navLinks = '';
    if ($role === 'admin') {
        $navLinks = '
            <li class="nav-item"><a class="nav-link" href="/lost_found/admin/dashboard.php">Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="/lost_found/admin/manage_reports.php">All Reports</a></li>
            <li class="nav-item"><a class="nav-link" href="/lost_found/admin/manage_claims.php">Claims</a></li>
            <li class="nav-item"><a class="nav-link" href="/lost_found/admin/handovers.php">Handovers</a></li>';
    } else {
        $navLinks = '
            <li class="nav-item"><a class="nav-link" href="/lost_found/user/dashboard.php">Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="/lost_found/user/report_lost.php">Report Lost</a></li>
            <li class="nav-item"><a class="nav-link" href="/lost_found/user/report_found.php">Report Found</a></li>
            <li class="nav-item"><a class="nav-link" href="/lost_found/user/search.php">Search</a></li>
            <li class="nav-item"><a class="nav-link" href="/lost_found/user/my_reports.php">My Reports</a></li>
            <li class="nav-item"><a class="nav-link" href="/lost_found/user/my_claims.php">My Claims</a></li>';
    }

    $userName = htmlspecialchars($_SESSION['name'] ?? 'User');
    echo <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{$title} | Lost & Found Portal</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="/lost_found/css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand fw-bold" href="/lost_found/index.php">
      <i class="bi bi-search-heart me-2"></i>Lost & Found Portal
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav me-auto">
        {$navLinks}
      </ul>
      <ul class="navbar-nav ms-auto">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle me-1"></i>{$userName}
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item text-danger" href="/lost_found/logout.php">
              <i class="bi bi-box-arrow-right me-1"></i>Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="container mt-4">
HTML;
}

function footer_html() {
    echo <<<HTML
</div><!-- /container -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="/lost_found/js/main.js"></script>
</body>
</html>
HTML;
}
