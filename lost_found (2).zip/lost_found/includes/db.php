<?php
// ─────────────────────────────────────────────────
//  Database Connection  (PDO)
//  University Lost & Found Portal
// ─────────────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_NAME', 'db_project');
define('DB_USER', 'root');
define('DB_PASS', '');          // Change to your MySQL password

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die("<div style='color:red;padding:20px;font-family:sans-serif;'>
         <strong>Database Connection Failed:</strong> " . htmlspecialchars($e->getMessage()) . "
         </div>");
}
