<?php
// ─────────────────────────────────────────────────
//  Auth Helper Functions
// ─────────────────────────────────────────────────

function requireLogin() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (empty($_SESSION['user_id'])) {
        header('Location: ' . getBase() . '/login.php');
        exit;
    }
}

function requireAdmin() {
    requireLogin();
    if ($_SESSION['role'] !== 'admin') {
        header('Location: ' . getBase() . '/user/dashboard.php');
        exit;
    }
}

function requireUser() {
    requireLogin();
    if ($_SESSION['role'] === 'admin') {
        header('Location: ' . getBase() . '/admin/dashboard.php');
        exit;
    }
}

function isLoggedIn() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    return !empty($_SESSION['user_id']);
}

// Helper to compute base URL path
function getBase() {
    // If the project is in a subdirectory like /lost_found/, this should return /lost_found
    // If it's at the root, it should return an empty string.
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
    $base = '/lost_found'; // Default to the hardcoded path used elsewhere in the project
    
    // Check if we are actually in that path
    if (strpos($script, $base) === 0) {
        return $base;
    }
    
    return '';
}

// Flash message helpers
function setFlash(string $type, string $msg) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}

function getFlash(): string {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        $cls = $f['type'] === 'success' ? 'alert-success' : ($f['type'] === 'danger' ? 'alert-danger' : 'alert-warning');
        return "<div class='alert {$cls} alert-dismissible fade show' role='alert'>
                    {$f['msg']}
                    <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                </div>";
    }
    return '';
}
